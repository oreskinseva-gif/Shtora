import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.font.FontRenderContext;
import java.awt.font.GlyphVector;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;

/**
 * Отрисовывает букву S из шрифта в PNG прямо во время сборки (GitHub Actions).
 *
 * Запуск:  java RenderS.java <deathnote.ttf> <папка-назначения>
 * Пишет logo_s.png (белая буква, прозрачный фон). Мод берёт эту картинку,
 * поэтому буква гарантированно готическая даже там, где в JRE нет java.desktop.
 */
public class RenderS {
    public static void main(String[] args) throws Exception {
        File ttf = new File(args[0]);
        File outDir = new File(args[1]);
        int W = 512, H = 943;
        float fillW = 0.86f, fillH = 0.92f;

        Font font = Font.createFont(Font.TRUETYPE_FONT, ttf).deriveFont(1000f);
        BufferedImage probe = new BufferedImage(1, 1, BufferedImage.TYPE_INT_ARGB);
        Graphics2D pg = probe.createGraphics();
        FontRenderContext frc = pg.getFontRenderContext();
        pg.dispose();

        GlyphVector gv = font.createGlyphVector(frc, new char[]{'S'});
        Rectangle2D b = gv.getVisualBounds();
        double s = Math.min((W * fillW) / b.getWidth(), (H * fillH) / b.getHeight());
        double tx = (W - b.getWidth() * s) / 2.0 - b.getX() * s;
        double ty = (H - b.getHeight() * s) / 2.0 - b.getY() * s;

        BufferedImage img = new BufferedImage(W, H, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = img.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
        g.setColor(Color.WHITE);
        g.translate(tx, ty);
        g.scale(s, s);
        g.fill(gv);
        g.dispose();

        outDir.mkdirs();
        File out = new File(outDir, "logo_s.png");
        ImageIO.write(img, "png", out);
        System.out.println("logo_s.png: " + out.getAbsolutePath() + " " + W + "x" + H);
    }
}
