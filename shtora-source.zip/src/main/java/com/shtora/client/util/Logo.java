package com.shtora.client.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;

/**
 * Буква S клиента.
 *
 * Раньше она рисовалась «по клеткам» и на большом размере выглядела пиксельной.
 * Теперь форма буквы описана формулой и один раз запекается в картинку с настоящим
 * сглаживанием краёв. На экран картинка просто растягивается, поэтому контур
 * остаётся гладким при любом размере.
 */
public final class Logo {
    private Logo() {}

    /** ширина / высота картинки буквы */
    public static final float RATIO = 100f / 142f;

    private static final int TW = 240, TH = 340;      // размер картинки в пикселях
    private static final float UW = 100f, UH = 142f;  // система координат буквы

    private static final Identifier ID_LINE = Identifier.of("shtora", "logo_line");
    private static final Identifier ID_BODY = Identifier.of("shtora", "logo_body");

    // ------------------------------------------------------------ форма буквы
    private static final float UX = 50f, UY = 38f, RU = 24f;   // верхняя дуга
    private static final float LX = 50f, LY = 102f, RL = 26f;  // нижняя дуга
    private static final float A1 = -50f, A2 = -230f;          // верхняя дуга: начало и конец
    private static final float B1 = -50f, B2 = 220f;           // нижняя дуга: начало и конец
    private static final float HMAX = 14.5f;                   // половина толщины в самом широком месте

    private static final float P1X, P1Y, P2X, P2Y;  // перемычка: начало и конец
    private static final float U0X, U0Y;            // свободный конец верхней дуги
    private static final float L0X, L0Y;            // свободный конец нижней дуги
    private static final float LEN1, LENSEG, LEN2, LENTOT;

    static {
        double a1 = Math.toRadians(A1), a2 = Math.toRadians(A2);
        double b1 = Math.toRadians(B1), b2 = Math.toRadians(B2);
        P1X = UX + RU * (float) Math.cos(a2);
        P1Y = UY + RU * (float) Math.sin(a2);
        P2X = LX + RL * (float) Math.cos(b1);
        P2Y = LY + RL * (float) Math.sin(b1);
        U0X = UX + RU * (float) Math.cos(a1);
        U0Y = UY + RU * (float) Math.sin(a1);
        L0X = LX + RL * (float) Math.cos(b2);
        L0Y = LY + RL * (float) Math.sin(b2);
        LEN1 = RU * (float) Math.toRadians(A1 - A2);
        LEN2 = RL * (float) Math.toRadians(B2 - B1);
        LENSEG = (float) Math.hypot(P2X - P1X, P2Y - P1Y);
        LENTOT = LEN1 + LENSEG + LEN2;
    }

    /** Половина толщины штриха: к концам буква тоньше — так она похожа на шрифт, а не на трубу. */
    private static float half(float s) {
        return HMAX * (0.70f + 0.30f * (float) Math.sin(Math.PI * s));
    }

    /** Расстояние до контура буквы: меньше нуля — внутри, больше — снаружи. */
    private static float sd(float px, float py) {
        float best = Float.MAX_VALUE;
        float ang = (float) Math.toDegrees(Math.atan2(py - UY, px - UX));

        // верхняя дуга
        float u;
        if (ang <= A1 && ang >= -180f) u = A1 - ang;
        else if (ang >= 130f) u = A1 - (ang - 360f);
        else u = -1f;
        if (u >= 0f) {
            float d = Math.abs((float) Math.hypot(px - UX, py - UY) - RU);
            best = Math.min(best, d - half(u / 180f * (LEN1 / LENTOT)));
        } else {
            float d1 = (float) Math.hypot(px - U0X, py - U0Y);
            float d2 = (float) Math.hypot(px - P1X, py - P1Y);
            best = Math.min(best, Math.min(d1 - half(0f), d2 - half(LEN1 / LENTOT)));
        }

        // нижняя дуга
        float b;
        if (ang >= B1 && ang <= 180f) b = ang - B1;
        else if (ang <= -140f) b = ang + 410f;
        else b = -1f;
        if (b >= 0f) {
            float d = Math.abs((float) Math.hypot(px - LX, py - LY) - RL);
            best = Math.min(best, d - half((LEN1 + LENSEG + b / 270f * LEN2) / LENTOT));
        } else {
            float d1 = (float) Math.hypot(px - P2X, py - P2Y);
            float d2 = (float) Math.hypot(px - L0X, py - L0Y);
            best = Math.min(best, Math.min(d1 - half((LEN1 + LENSEG) / LENTOT), d2 - half(1f)));
        }

        // перемычка между дугами
        float dx = P2X - P1X, dy = P2Y - P1Y;
        float len2 = dx * dx + dy * dy;
        float t = len2 <= 0f ? 0f : ((px - P1X) * dx + (py - P1Y) * dy) / len2;
        t = t < 0f ? 0f : (t > 1f ? 1f : t);
        float qx = P1X + t * dx, qy = P1Y + t * dy;
        float ds = (float) Math.hypot(px - qx, py - qy);
        best = Math.min(best, ds - half((LEN1 + t * LENSEG) / LENTOT));

        return best;
    }

    // ------------------------------------------------------------ запекание картинки
    private static boolean ready;
    private static boolean failed;
    private static float[] dots = new float[0];

    /** Точки внутри буквы — к ним летят частицы в интро. Координаты 0..1. */
    public static float[] dots() {
        build();
        return dots;
    }

    private static void build() {
        if (ready || failed) return;
        try {
            float pix = UW / TW;
            final float EDGE = 2.2f;   // полуширина контура
            final float GLOW = 15f;    // радиус свечения

            NativeImage line = new NativeImage(TW, TH, false);
            NativeImage body = new NativeImage(TW, TH, false);
            java.util.ArrayList<Float> pts = new java.util.ArrayList<>();

            for (int j = 0; j < TH; j++) {
                float py = (j + 0.5f) * UH / TH;
                for (int i = 0; i < TW; i++) {
                    float px = (i + 0.5f) * UW / TW;
                    float d = sd(px, py);
                    float ad = Math.abs(d);

                    float cov = clamp(0.5f - d / pix);
                    float edge = clamp(0.5f - (ad - EDGE) / pix);
                    float glow = 1f - ad / GLOW;
                    if (glow < 0f) glow = 0f;
                    glow = glow * glow * 0.55f;

                    line.setColorArgb(i, j, white(Math.max(edge, glow)));
                    body.setColorArgb(i, j, white(cov));

                    if (cov > 0.6f && i % 10 == 5 && j % 10 == 5) {
                        pts.add((i + 0.5f) / TW);
                        pts.add((j + 0.5f) / TH);
                    }
                }
            }

            MinecraftClient mc = MinecraftClient.getInstance();
            register(mc, ID_LINE, line);
            register(mc, ID_BODY, body);

            float[] out = new float[pts.size()];
            for (int i = 0; i < out.length; i++) out[i] = pts.get(i);
            dots = out;
            ready = true;
        } catch (Throwable t) {
            failed = true;
            t.printStackTrace();
        }
    }

    private static void register(MinecraftClient mc, Identifier id, NativeImage image) {
        NativeImageBackedTexture tex = new NativeImageBackedTexture(image);
        mc.getTextureManager().registerTexture(id, tex);
        tex.setFilter(true, false); // гладкое растягивание вместо квадратиков
    }

    private static float clamp(float v) { return v < 0f ? 0f : (v > 1f ? 1f : v); }

    private static int white(float a) {
        int al = (int) (clamp(a) * 255f + 0.5f);
        return (al << 24) | 0xFFFFFF;
    }

    // ------------------------------------------------------------ отрисовка
    /** Контур буквы вместе с мягким свечением вокруг. */
    public static void line(DrawContext ctx, int x, int y, int w, int h, int rgb, float a) {
        draw(ctx, ID_LINE, x, y, w, h, rgb, a);
    }

    /** Залитая буква. */
    public static void body(DrawContext ctx, int x, int y, int w, int h, int rgb, float a) {
        draw(ctx, ID_BODY, x, y, w, h, rgb, a);
    }

    private static void draw(DrawContext ctx, Identifier id, int x, int y, int w, int h, int rgb, float a) {
        if (a < 0.02f || w <= 0 || h <= 0) return;
        build();
        if (failed) return;
        ctx.drawTexture(RenderLayer::getGuiTextured, id, x, y, 0f, 0f, w, h, TW, TH, Draw.argb(rgb, a));
    }

    /** Размер буквы при заданной высоте. */
    public static int widthFor(int height) { return Math.max(1, Math.round(height * RATIO)); }
}
