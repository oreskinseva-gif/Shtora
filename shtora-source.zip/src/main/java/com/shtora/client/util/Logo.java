package com.shtora.client.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;

/**
 * Буква S клиента.
 *
 * Форма описана формулой (две дуги + перемычка) и один раз запекается в две картинки:
 *  - body — залитая буква со сглаженными краями;
 *  - line — тонкий контур со свечением вокруг.
 * На экран картинки просто масштабируются с билинейной фильтрацией, поэтому буква
 * остаётся гладкой на любом размере и не выглядит пиксельной.
 */
public final class Logo {
    private Logo() {}

    /** отношение ширины буквы к высоте */
    public static final float RATIO = 76f / 140f;

    private static final int TW = 320, TH = 589;      // размер картинки в пикселях
    private static final float UW = 76f, UH = 140f;   // система координат буквы

    private static final Identifier ID_LINE = Identifier.of("shtora", "logo_line");
    private static final Identifier ID_BODY = Identifier.of("shtora", "logo_body");

    // ------------------------------------------------------------ форма буквы
    private static final float CX = 38f;               // центр буквы по горизонтали
    private static final float CY1 = 39.5f;            // центр верхней чаши
    private static final float CY2 = 100.5f;           // центр нижней чаши
    private static final float R = 27f;                // радиус чаш по осевой линии
    private static final float A1 = -52f, A2 = -232f;  // верхняя дуга: начало и конец
    private static final float B1 = -52f, B2 = 152f;   // нижняя дуга: начало и конец
    private static final float HMAX = 10.5f;           // половина толщины штриха

    private static final float P1X, P1Y, P2X, P2Y;     // перемычка: начало и конец
    private static final float LEN1, LENSEG, LEN2, LENTOT;

    static {
        P1X = ptX(CX, R, A2); P1Y = ptY(CY1, R, A2);
        P2X = ptX(CX, R, B1); P2Y = ptY(CY2, R, B1);
        LEN1 = R * (float) Math.toRadians(Math.abs(A2 - A1));
        LEN2 = R * (float) Math.toRadians(Math.abs(B2 - B1));
        LENSEG = (float) Math.hypot(P2X - P1X, P2Y - P1Y);
        LENTOT = LEN1 + LENSEG + LEN2;
    }

    /** Половина толщины штриха: к концам буква чуть тоньше — так она похожа на шрифт. */
    private static float half(float s) {
        return HMAX * (0.82f + 0.18f * (float) Math.sin(Math.PI * s));
    }

    /** Расстояние до контура буквы: меньше нуля — внутри, больше — снаружи. */
    private static float sd(float px, float py) {
        float f1 = LEN1 / LENTOT;
        float f2 = (LEN1 + LENSEG) / LENTOT;
        float best = arcDist(px, py, CX, CY1, R, A1, A2, 0f, f1);
        best = Math.min(best, segDist(px, py, P1X, P1Y, P2X, P2Y, f1, f2));
        best = Math.min(best, arcDist(px, py, CX, CY2, R, B1, B2, f2, 1f));
        return best;
    }

    /** Расстояние до дуги окружности с круглыми концами. */
    private static float arcDist(float px, float py, float cx, float cy, float r,
                                 float a0, float a1, float s0, float s1) {
        float dist = (float) Math.hypot(px - cx, py - cy);
        float ang = (float) Math.toDegrees(Math.atan2(py - cy, px - cx));
        float span = a1 - a0;
        float rel = span >= 0f ? norm360(ang - a0) : norm360(a0 - ang);
        float spanAbs = Math.abs(span);
        if (rel <= spanAbs) {
            return Math.abs(dist - r) - half(s0 + (s1 - s0) * (rel / spanAbs));
        }
        float toEnd = spanAbs - rel;
        if (rel <= toEnd) {
            return (float) Math.hypot(px - ptX(cx, r, a0), py - ptY(cy, r, a0)) - half(s0);
        }
        return (float) Math.hypot(px - ptX(cx, r, a1), py - ptY(cy, r, a1)) - half(s1);
    }

    /** Расстояние до отрезка (с той же толщиной штриха). */
    private static float segDist(float px, float py, float x1, float y1, float x2, float y2,
                                 float s0, float s1) {
        float dx = x2 - x1, dy = y2 - y1;
        float len2 = dx * dx + dy * dy;
        float t = len2 <= 0f ? 0f : ((px - x1) * dx + (py - y1) * dy) / len2;
        t = t < 0f ? 0f : (t > 1f ? 1f : t);
        float ds = (float) Math.hypot(px - (x1 + t * dx), py - (y1 + t * dy));
        return ds - half(s0 + (s1 - s0) * t);
    }

    private static float norm360(float a) {
        a = a % 360f;
        return a < 0f ? a + 360f : a;
    }

    private static float ptX(float c, float r, float deg) { return c + r * (float) Math.cos(Math.toRadians(deg)); }
    private static float ptY(float c, float r, float deg) { return c + r * (float) Math.sin(Math.toRadians(deg)); }

    // ------------------------------------------------------------ запекание картинки
    private static boolean ready;
    private static boolean failed;
    private static float[] dots = new float[0];

    /** Точки внутри буквы — к ним летят частицы в интро. Координаты 0..1. */
    public static float[] dots() {
        build();
        return dots;
    }

    private static void build() {
        if (ready || failed) return;
        try {
            float pix = UW / TW;
            final float EDGE = 1.9f;   // полуширина контура
            final float GLOW = 15f;    // радиус свечения

            NativeImage line = new NativeImage(TW, TH, false);
            NativeImage body = new NativeImage(TW, TH, false);
            java.util.ArrayList<Float> pts = new java.util.ArrayList<>();

            for (int j = 0; j < TH; j++) {
                float py = (j + 0.5f) * UH / TH;
                for (int i = 0; i < TW; i++) {
                    float px = (i + 0.5f) * UW / TW;
                    float d = sd(px, py);
                    float ad = Math.abs(d);

                    float cov = clamp(0.5f - d / pix);
                    float edge = clamp(0.5f - (ad - EDGE) / pix);
                    float glow = 1f - ad / GLOW;
                    if (glow < 0f) glow = 0f;
                    glow = glow * glow * 0.6f;

                    line.setColorArgb(i, j, white(Math.max(edge, glow)));
                    body.setColorArgb(i, j, white(cov));

                    if (cov > 0.6f && i % 9 == 4 && j % 9 == 4) {
                        pts.add((i + 0.5f) / TW);
                        pts.add((j + 0.5f) / TH);
                    }
                }
            }

            MinecraftClient mc = MinecraftClient.getInstance();
            register(mc, ID_LINE, line);
            register(mc, ID_BODY, body);

            float[] out = new float[pts.size()];
            for (int i = 0; i < out.length; i++) out[i] = pts.get(i);
            dots = out;
            ready = true;
        } catch (Throwable t) {
            failed = true;
            t.printStackTrace();
        }
    }

    private static void register(MinecraftClient mc, Identifier id, NativeImage image) {
        NativeImageBackedTexture tex = new NativeImageBackedTexture(image);
        mc.getTextureManager().registerTexture(id, tex);
        tex.setFilter(true, false); // гладкое растягивание вместо квадратиков
    }

    private static float clamp(float v) { return v < 0f ? 0f : (v > 1f ? 1f : v); }

    private static int white(float a) {
        int al = (int) (clamp(a) * 255f + 0.5f);
        return (al << 24) | 0xFFFFFF;
    }

    // ------------------------------------------------------------ отрисовка
    /** Контур буквы вместе с мягким свечением вокруг. */
    public static void line(DrawContext ctx, int x, int y, int w, int h, int rgb, float a) {
        draw(ctx, ID_LINE, x, y, w, h, rgb, a);
    }

    /** Залитая буква. */
    public static void body(DrawContext ctx, int x, int y, int w, int h, int rgb, float a) {
        draw(ctx, ID_BODY, x, y, w, h, rgb, a);
    }

    private static void draw(DrawContext ctx, Identifier id, int x, int y, int w, int h, int rgb, float a) {
        if (a < 0.02f || w <= 0 || h <= 0) return;
        build();
        if (failed) return;
        // 13-аргументный overload: regionWidth/regionHeight — рисуем ВСЮ текстуру, а не её угол
        ctx.drawTexture(RenderLayer::getGuiTextured, id, x, y, 0f, 0f, w, h, TW, TH, TW, TH, Draw.argb(rgb, a));
    }

    /** Размер буквы при заданной высоте. */
    public static int widthFor(int height) { return Math.max(1, Math.round(height * RATIO)); }
}
