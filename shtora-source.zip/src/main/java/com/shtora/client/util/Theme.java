package com.shtora.client.util;

import com.shtora.client.ModuleManager;

/** Палитра клиента: синий (чуть голубой) акцент + тёмные холодные панели. */
public final class Theme {
    private Theme() {}

    // синий с лёгким голубым оттенком (210°), меняется ползунком Accent в модуле Interface
    public static final float DEFAULT_HUE = 210f / 360f;

    public static final int BG_TOP = 0x05070D;
    public static final int BG_BOTTOM = 0x0D1524;
    public static final int PANEL = 0x0A0F19;
    public static final int PANEL_ALT = 0x111827;
    public static final int BORDER = 0x223149;
    public static final int TEXT = 0xEAF1FB;
    public static final int TEXT_DIM = 0x8B98AD;

    public static int accent() { return accent(0f); }

    /** Акцентный цвет; shift даёт небольшой сдвиг оттенка (волна в списке модулей). */
    public static int accent(float shift) {
        float base = ModuleManager.ui == null ? DEFAULT_HUE : (float) ModuleManager.ui.hue.get() / 360f;
        return Draw.hsb(base + shift * 0.10f, 0.80f, 1.0f);
    }
}
