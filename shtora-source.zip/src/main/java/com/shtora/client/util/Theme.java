package com.shtora.client.util;

import com.shtora.client.ModuleManager;

/** Палитра клиента: оранжевый акцент CS2 + тёмные панели. */
public final class Theme {
    private Theme() {}

    // оранжевый CS2 по умолчанию (33°), меняется ползунком Accent в модуле Interface
    public static final float DEFAULT_HUE = 33f / 360f;

    public static final int BG_TOP = 0x07090C;
    public static final int BG_BOTTOM = 0x13171D;
    public static final int PANEL = 0x0E1116;
    public static final int PANEL_ALT = 0x161A21;
    public static final int BORDER = 0x2A2F38;
    public static final int TEXT = 0xE6E8EC;
    public static final int TEXT_DIM = 0x8A9099;

    public static int accent() { return accent(0f); }

    /** Акцентный цвет; shift даёт небольшой сдвиг оттенка (волна в списке модулей). */
    public static int accent(float shift) {
        float base = ModuleManager.ui == null ? DEFAULT_HUE : (float) ModuleManager.ui.hue.get() / 360f;
        return Draw.hsb(base + shift * 0.10f, 0.80f, 0.94f);
    }
}
