package com.shtora.client;

import com.shtora.client.modules.*;
import com.shtora.client.setting.BoolSetting;
import com.shtora.client.setting.ModeSetting;
import com.shtora.client.setting.NumberSetting;
import java.util.ArrayList;
import java.util.List;

public class ModuleManager {
    public static final List<Module> modules = new ArrayList<>();

    public static Interface ui;
    public static KillAura killAura;
    public static Esp esp;
    public static Scaffold scaffold;
    public static Tracers tracers;
    public static NameTags nameTags;
    public static BlockHighlight blockHighlight;
    public static Morph morph;
    public static HudModule targetHud, armorHud, potionHud, keystrokes, coords, radar, invHud, itemCounter, infoHud;
    public static BoolSetting showBps, radarMobs, thPlayers, thMobs;
    public static ModeSetting thMode;
    public static NumberSetting thRadius;
    public static NumberSetting radarRange;

    public static void init() {
        ui = new Interface();
        killAura = new KillAura();
        esp = new Esp();
        scaffold = new Scaffold();
        tracers = new Tracers();
        nameTags = new NameTags();
        blockHighlight = new BlockHighlight();
        morph = new Morph();
        invHud = new HudModule("InventoryHUD");
        itemCounter = new HudModule("ItemCounter");
        infoHud = new HudModule("InfoHUD");
        targetHud = new HudModule("TargetHUD");
        thMode = targetHud.with(new ModeSetting("Mode", "Radius", "Crosshair", "KillAura"));
        thRadius = targetHud.with(new NumberSetting("Radius", 10, 3, 40, 1));
        thPlayers = targetHud.with(new BoolSetting("Players", true));
        thMobs = targetHud.with(new BoolSetting("Mobs", false));
        armorHud = new HudModule("ArmorHUD");
        potionHud = new HudModule("PotionHUD");
        keystrokes = new HudModule("Keystrokes");
        coords = new HudModule("Coordinates");
        showBps = coords.with(new BoolSetting("Show BPS", true));
        radar = new HudModule("Radar");
        radarRange = radar.with(new NumberSetting("Range", 40, 10, 100, 5));
        radarMobs = radar.with(new BoolSetting("Mobs", false));

        // Combat
        modules.add(killAura);
        modules.add(new AimAssist());
        modules.add(new TriggerBot());
        modules.add(new Velocity());
        modules.add(new AutoTotem());
        modules.add(new Hitbox());
        // Movement
        modules.add(new Sprint());
        modules.add(new Fly());
        modules.add(new BHop());
        // Render
        modules.add(ui);
        modules.add(new FullBright());
        modules.add(new Zoom());
        modules.add(new TimeChanger());
        modules.add(new NoWeather());
        modules.add(new ShowHitboxes());
        modules.add(esp);
        modules.add(tracers);
        modules.add(nameTags);
        modules.add(blockHighlight);
        modules.add(new NoBob());
        modules.add(morph);
        modules.add(targetHud);
        modules.add(armorHud);
        modules.add(potionHud);
        modules.add(keystrokes);
        modules.add(coords);
        modules.add(radar);
        modules.add(invHud);
        modules.add(itemCounter);
        modules.add(infoHud);
        // Player / Misc
        modules.add(scaffold);
        modules.add(new AutoRespawn());
        modules.add(new NoFall());
        modules.add(new AutoEat());
        modules.add(new AutoArmor());
        modules.add(new AutoTool());
        modules.add(new Sneak());
        modules.add(new AntiAFK());
        modules.add(new AutoWalk());
        modules.add(new Spin());
        modules.add(new Panic());
    }

    public static List<Module> byCategory(Category c) {
        List<Module> out = new ArrayList<>();
        for (Module m : modules) if (m.category == c) out.add(m);
        return out;
    }
}
