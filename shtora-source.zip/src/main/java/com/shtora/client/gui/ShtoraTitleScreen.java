package com.shtora.client.gui;

import com.mojang.authlib.GameProfile;
import com.shtora.client.util.Anim;
import com.shtora.client.util.Draw;
import com.shtora.client.util.Logo;
import com.shtora.client.util.Theme;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.PlayerSkinDrawer;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.client.session.Session;
import net.minecraft.client.util.SkinTextures;
import net.minecraft.text.Text;
import java.nio.charset.StandardCharsets;
import java.util.UUID;

/**
 * Главный экран Shtora в стиле FDP: тёмная холодная подложка, мягкое синее свечение,
 * скруглённые карточки и кнопки, тонкие рамки и акцентная полоса.
 *
 * Сначала короткое интро: ниже середины плавно появляется «Добро пожаловать» с ником,
 * затем буква S собирается из мелких частиц (контур со свечением виден сразу),
 * после полного заполнения — плавный переход в само меню.
 *
 * Сама буква рисуется из {@link Logo} — заранее запечённой картинки со сглаженными краями,
 * поэтому она гладкая при любом размере, а не «пиксельная».
 */
public class ShtoraTitleScreen extends Screen {
    // ---------------------------------------------------------------- тайминги интро (секунды)
    private static final float T_WELCOME = 0.35f, T_WELCOME_END = 1.15f;
    private static final float T_OUTLINE = 0.45f, T_OUTLINE_END = 1.10f;
    private static final float T_PARTICLES = 0.85f, T_PARTICLE_SPREAD = 0.85f, T_PARTICLE_DUR = 0.95f;
    private static final float T_MENU = 3.30f, T_MENU_END = 3.95f;

    /** Интро показываем только при первом входе, при возврате из мира — сразу меню. */
    private static boolean introShown;

    private final long start;
    private final Anim[] btnAnim = {new Anim(0), new Anim(0), new Anim(0), new Anim(0)};
    private final int[] btnX = new int[4], btnY = new int[4], btnW = new int[4], btnH = new int[4];
    private final String[] btnLabel = {"ОДИНОЧНАЯ ИГРА", "СЕТЕВАЯ ИГРА", "НАСТРОЙКИ", "ВЫХОД"};
    private final String[] btnLabelShort = {"ОДИНОЧНАЯ", "СЕТЕВАЯ", "НАСТРОЙКИ", "ВЫХОД"};

    /** Точки внутри буквы S (парами x,y в диапазоне 0..1) — к ним летят частицы. */
    private final float[] dots;
    private float menuA, introA;
    private int hoverBtn = -1;

    private SkinTextures skin;
    private String nick = "Player";

    public ShtoraTitleScreen() {
        super(Text.empty());
        start = introShown ? System.currentTimeMillis() - 10_000L : System.currentTimeMillis();
        introShown = true;
        dots = Logo.dots();
    }

    @Override public boolean shouldCloseOnEsc() { return false; }
    @Override public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {}

    @Override
    protected void init() {
        loadPlayer();
    }

    private void loadPlayer() {
        try {
            Session s = client.getSession();
            nick = s.getUsername() == null || s.getUsername().isEmpty() ? "Player" : s.getUsername();
            UUID id = s.getUuidOrNull();
            if (id == null) id = UUID.nameUUIDFromBytes(("OfflinePlayer:" + nick).getBytes(StandardCharsets.UTF_8));
            skin = client.getSkinProvider().getSkinTextures(new GameProfile(id, nick));
        } catch (Throwable t) {
            skin = null;
        }
    }

    // ---------------------------------------------------------------- рендер
    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        TextRenderer tr = client.textRenderer;
        int sw = width, sh = height;
        int acc = Theme.accent();
        float t = (System.currentTimeMillis() - start) / 1000f;

        menuA = smooth((t - T_MENU) / (T_MENU_END - T_MENU));
        introA = 1f - menuA;

        Draw.vgrad(ctx, 0, 0, sw, sh, Theme.BG_TOP, Theme.BG_BOTTOM, 1f);
        backdrop(ctx, sw, sh, acc);

        if (introA > 0.01f) drawIntro(ctx, tr, sw, sh, acc, t, introA);
        if (menuA > 0.01f) drawMenu(ctx, tr, sw, sh, acc, mouseX, mouseY, delta, menuA);
    }

    /** Фон: мягкое синее свечение снизу, светящийся силуэт S по центру и бледная буква справа. */
    private void backdrop(DrawContext ctx, int sw, int sh, int acc) {
        for (int k = 7; k >= 1; k--)
            ctx.fill(0, sh - k * 16, sw, sh - (k - 1) * 16, Draw.argb(acc, 0.013f * k));
        int gh = Math.round(Math.min(sw, sh) * 0.86f);
        int gw = Logo.widthFor(gh);
        Logo.line(ctx, (sw - gw) / 2, Math.round(sh * 0.34f) - gh / 2, gw, gh, acc, 0.13f);
        int lh = Math.max(60, Math.min(150, sw / 12));
        int lw = Logo.widthFor(lh);
        Logo.body(ctx, sw - lw - 4, (sh - lh) / 2, lw, lh, acc, 0.035f);
    }

    // ---------------------------------------------------------------- интро
    private void drawIntro(DrawContext ctx, TextRenderer tr, int sw, int sh, int acc, float t, float a) {
        int lh = Math.max(96, Math.min(210, Math.round(Math.min(sw, sh) * 0.30f)));
        int lw = Logo.widthFor(lh);
        int lx = (sw - lw) / 2, ly = Math.round(sh * 0.34f) - lh / 2;

        // буква плавно проявляется, а контур со свечением виден с самого начала
        int n = dots.length / 2;
        float prog = Draw.ease(Draw.clamp((t - T_PARTICLES) / (T_PARTICLE_SPREAD + T_PARTICLE_DUR)));
        if (prog > 0.02f) {
            Logo.body(ctx, lx, ly, lw, lh, Draw.mix(acc, 0xFFFFFF, 0.18f), prog * a);
        }
        float oa = smooth((t - T_OUTLINE) / (T_OUTLINE_END - T_OUTLINE)) * a;
        if (oa > 0.01f) {
            float pulse = 0.6f + 0.4f * (float) Math.sin(t * 2.4);
            Logo.line(ctx, lx, ly, lw, lh, acc, (0.5f + 0.35f * pulse) * oa);
        }
        if (n > 0 && t >= T_PARTICLES - 0.2f) {
            int ps = Math.max(1, lw / 34);
            for (int k = 0; k < n; k++) {
                float delay = T_PARTICLES + rnd(k, 1) * T_PARTICLE_SPREAD;
                float p = Draw.ease(Draw.clamp((t - delay) / T_PARTICLE_DUR));
                if (p <= 0.002f) continue;
                float tx = lx + dots[k * 2] * lw, ty = ly + dots[k * 2 + 1] * lh;
                float sx = tx + (rnd(k, 2) - 0.5f) * sw * 1.25f;
                float sy = ty + (rnd(k, 3) - 0.5f) * sh * 1.25f;
                float px = sx + (tx - sx) * p, py = sy + (ty - sy) * p;
                int sz = Math.max(1, Math.round(ps * (0.45f + 0.55f * p)));
                ctx.fill(Math.round(px), Math.round(py), Math.round(px) + sz, Math.round(py) + sz,
                        Draw.argb(acc, a * (0.30f + 0.55f * p)));
            }
        }

        // короткая вспышка, когда буква собралась целиком
        if (prog > 0.985f) {
            float flash = Draw.clamp(1f - Math.abs(t - (T_PARTICLES + T_PARTICLE_SPREAD + T_PARTICLE_DUR)) / 0.3f);
            if (flash > 0.01f) Logo.body(ctx, lx, ly, lw, lh, 0xFFFFFF, 0.22f * flash * a);
        }

        // «Добро пожаловать» + ник — ниже середины
        float wa = smooth((t - T_WELCOME) / (T_WELCOME_END - T_WELCOME)) * a;
        if (wa > 0.01f) {
            String l1 = "Добро пожаловать";
            String l2 = nick;
            int y = Math.round(sh * 0.62f);
            Draw.text(ctx, tr, l1, (sw - Draw.w(tr, l1)) / 2, y, Theme.TEXT, wa);
            Draw.text(ctx, tr, l2, (sw - Draw.w(tr, l2)) / 2, y + 16, acc, wa);
        }
    }

    // ---------------------------------------------------------------- меню
    private void drawMenu(DrawContext ctx, TextRenderer tr, int sw, int sh, int acc,
                          int mx, int my, float delta, float a) {
        // верхняя акцентная линия с плавным затуханием к краям
        for (int i = 0; i < 40; i++) {
            float f = 1f - Math.abs(i / 39f - 0.5f) * 2f;
            ctx.fill(sw * i / 40, 0, sw * (i + 1) / 40 + 1, 2, Draw.argb(acc, a * (0.35f + 0.65f * f)));
        }

        // логотип
        Draw.rrect(ctx, 12, 8, 24, 24, 6, Draw.argb(acc, a));
        Draw.rrect(ctx, 13, 9, 22, 22, 5, Draw.argb(Draw.mix(Theme.PANEL, acc, 0.10f), a));
        int mlh = 15, mlw = Logo.widthFor(mlh);
        Logo.body(ctx, 12 + (24 - mlw) / 2, 8 + (24 - mlh) / 2, mlw, mlh, acc, a);
        Draw.text(ctx, tr, "SHTORA", 42, 16, acc, a);
        Draw.text(ctx, tr, " CLIENT", 42 + Draw.w(tr, "SHTORA"), 16, Theme.TEXT, a);

        String ver = "FABRIC 1.21.4";
        Draw.text(ctx, tr, ver, sw - 14 - Draw.w(tr, ver), 16, Theme.TEXT_DIM, a * 0.9f);

        // карточка игрока
        int cardW = Math.min(340, sw - 20), cardH = 54;
        int cardX = (sw - cardW) / 2, cardY = 44;
        Draw.rrect(ctx, cardX, cardY, cardW, cardH, 7, Draw.argb(Theme.PANEL_ALT, 0.9f * a));
        Draw.outline(ctx, cardX, cardY, cardW, cardH, 7, Draw.argb(Theme.BORDER, 0.95f * a));
        Draw.rrect(ctx, cardX, cardY + 6, 3, cardH - 12, 2, Draw.argb(acc, a));

        int px = cardX + 11, py = cardY + 11;
        if (skin != null) {
            try { PlayerSkinDrawer.draw(ctx, skin, px, py, 32); }
            catch (Throwable ignored) { ctx.fill(px, py, px + 32, py + 32, Draw.argb(0x141B28, a)); }
        } else {
            ctx.fill(px, py, px + 32, py + 32, Draw.argb(0x141B28, a));
        }
        Draw.outline(ctx, px - 1, py - 1, 34, 34, 3, Draw.argb(acc, 0.6f * a));

        Draw.text(ctx, tr, Draw.trim(tr, nick, cardW - 70), cardX + 52, cardY + 14, Theme.TEXT, a);
        Draw.text(ctx, tr, "SHTORA CLIENT", cardX + 52, cardY + 28, acc, a * 0.92f);
        String st = "ОНЛАЙН";
        Draw.text(ctx, tr, st, cardX + cardW - 12 - Draw.w(tr, st), cardY + 14, Theme.TEXT_DIM, a * 0.8f);

        // кнопки
        int gap = 8;
        int top = cardY + cardH + 16;
        int bottom = sh - 26;
        int space = Math.max(56, bottom - top);
        boolean grid = space < 4 * 24 + 3 * gap;
        if (grid) {
            int bw = Math.min(170, (Math.min(340, sw - 24) - gap) / 2);
            int bh = Math.max(18, Math.min(28, (space - gap) / 2));
            int x0 = (sw - (bw * 2 + gap)) / 2;
            for (int i = 0; i < 4; i++) {
                btnX[i] = x0 + (i % 2) * (bw + gap);
                btnY[i] = top + (i / 2) * (bh + gap);
                btnW[i] = bw;
                btnH[i] = bh;
            }
        } else {
            int bw = Math.min(280, sw - 32);
            int bh = Math.max(20, Math.min(32, (space - 3 * gap) / 4));
            int x0 = (sw - bw) / 2;
            for (int i = 0; i < 4; i++) {
                btnX[i] = x0;
                btnY[i] = top + i * (bh + gap);
                btnW[i] = bw;
                btnH[i] = bh;
            }
        }

        hoverBtn = -1;
        for (int i = 0; i < 4; i++)
            if (in(mx, my, btnX[i], btnY[i], btnW[i], btnH[i])) hoverBtn = i;

        for (int i = 0; i < 4; i++) {
            btnAnim[i].to(i == hoverBtn ? 1f : 0f, 16f, delta);
            String label = grid ? btnLabelShort[i] : btnLabel[i];
            drawButton(ctx, tr, btnX[i], btnY[i], btnW[i], btnH[i], label, btnAnim[i].v, a, acc);
        }

        // подсказка про меню клиента
        String hint = "ПРАВЫЙ SHIFT — МЕНЮ КЛИЕНТА В ИГРЕ";
        Draw.text(ctx, tr, hint, (sw - Draw.w(tr, hint)) / 2, sh - 17, Theme.TEXT_DIM, a * 0.85f);
    }

    private void drawButton(DrawContext ctx, TextRenderer tr, int x, int y, int w, int h,
                            String label, float hov, float a, int acc) {
        int bg = Draw.mix(0x111827, acc, 0.18f * hov);
        Draw.rrect(ctx, x, y, w, h, 6, Draw.argb(bg, 0.92f * a));
        Draw.outline(ctx, x, y, w, h, 6, Draw.argb(Draw.mix(Theme.BORDER, acc, hov), (0.7f + 0.3f * hov) * a));
        if (hov > 0.02f)
            Draw.rrect(ctx, x, y, w, h, 6, Draw.argb(acc, 0.10f * hov * a));

        int barW = 3 + Math.round(hov * 4);
        Draw.rrect(ctx, x, y, barW, h, 3, Draw.argb(acc, a));

        String lbl = Draw.trim(tr, label, w - barW - 22);
        Draw.text(ctx, tr, lbl, x + barW + 10, y + (h - 8) / 2, Draw.mix(Theme.TEXT, 0xFFFFFF, hov), a);

        int ax = x + w - 13 + Math.round(hov * 3), cy = y + h / 2;
        int ac = Draw.argb(acc, (0.4f + 0.6f * hov) * a);
        Draw.line(ctx, ax, cy - 3, ax + 3, cy, ac);
        Draw.line(ctx, ax + 3, cy, ax, cy + 3, ac);
    }

    // ---------------------------------------------------------------- ввод
    private static boolean in(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (menuA < 0.9f) return true;
        for (int i = 0; i < 4; i++) {
            if (!in(mx, my, btnX[i], btnY[i], btnW[i], btnH[i])) continue;
            switch (i) {
                case 0 -> client.setScreen(new SelectWorldScreen(this));
                case 1 -> client.setScreen(new MultiplayerScreen(this));
                case 2 -> client.setScreen(new OptionsScreen(this, client.options));
                case 3 -> client.scheduleStop();
            }
            return true;
        }
        return true;
    }

    // ---------------------------------------------------------------- утилиты
    private static float smooth(float x) {
        x = Draw.clamp(x);
        return x * x * (3f - 2f * x);
    }

    /** Устойчивое псевдослучайное число 0..1 по индексу — частицы не «дрожат» между кадрами. */
    private static float rnd(int i, int salt) {
        int x = i * 374761393 + salt * 668265263;
        x = (x ^ (x >> 13)) * 1274126177;
        x ^= (x >> 16);
        return (x & 0x7FFFFFFF) / (float) 0x7FFFFFFF;
    }
}
