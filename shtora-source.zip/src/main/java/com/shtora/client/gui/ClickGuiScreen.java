package com.shtora.client.gui;

import com.shtora.client.Category;
import com.shtora.client.Module;
import com.shtora.client.ModuleManager;
import com.shtora.client.setting.BoolSetting;
import com.shtora.client.setting.ModeSetting;
import com.shtora.client.setting.NumberSetting;
import com.shtora.client.setting.Setting;
import com.shtora.client.util.Anim;
import com.shtora.client.util.Draw;
import com.shtora.client.util.Logo;
import com.shtora.client.util.Theme;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Меню клиента в стиле «карточек» (как в SystemDLC):
 * тёмный фон со звёздами, слева узкая панель (Keybinds / Potions / Position),
 * справа сетка панелей категорий. В каждой панели — модули строками:
 * название, подпись и округлый переключатель. Логика (поиск, скролл, слайдеры,
 * режимы) сохранена полностью.
 */
public class ClickGuiScreen extends Screen {
    private static final int TOP = 26, BOT = 20;      // верхняя и нижняя полосы
    private static final int ROW = 28, HEAD = 22;     // высота строки модуля и шапки панели
    private static final int PAD = 6, GAP = 6;        // отступы

    private static final class Panel {
        Category cat; int x, y, w, h;
    }

    private static final class Chip {
        ModeSetting mo; int idx, x, y, w, h;
    }

    private final Anim open = new Anim(0), scroll = new Anim(0), searchAnim = new Anim(0);
    private final List<Panel> panels = new ArrayList<>();
    private final List<Chip> chips = new ArrayList<>();
    private final List<Module> visible = new ArrayList<>();
    private final List<Module> results = new ArrayList<>();
    private final StringBuilder query = new StringBuilder();

    private boolean closing, searching;
    private float scrollTarget, maxScroll, contentH, frameDt = 0.016f;
    private long last = System.nanoTime();

    private int sideW, mainX, mainY, mainW, mainH;
    private int searchX, searchY, searchW, searchH;
    private int pressArea;
    private double pressX, pressY, moved;
    private NumberSetting dragSlider;

    public ClickGuiScreen() {
        super(Text.empty());
    }

    @Override public boolean shouldPause() { return false; }
    @Override public void close() { closing = true; }
    @Override public void renderBackground(DrawContext ctx, int mx, int my, float delta) {}

    // ------------------------------------------------------------ клавиатура
    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (searching) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE) { stopSearch(); return true; }
            if (keyCode == GLFW.GLFW_KEY_BACKSPACE) {
                if (query.length() > 0) query.setLength(query.length() - 1);
                return true;
            }
        }
        if (keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT && !searching) { close(); return true; }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (searching && chr >= 32 && query.length() < 24) {
            query.append(chr);
            scrollTarget = 0f;
            return true;
        }
        return super.charTyped(chr, modifiers);
    }

    private void stopSearch() { searching = false; query.setLength(0); }

    // ------------------------------------------------------------ раскладка настроек
    private static int modeRows(TextRenderer tr, ModeSetting mo, int innerW) {
        int rows = 1, cx = 0;
        for (String m : mo.modes) {
            int w = Draw.w(tr, m) + 12;
            if (cx + w > innerW && cx > 0) { rows++; cx = 0; }
            cx += w + 4;
        }
        return rows;
    }

    private static int settingH(TextRenderer tr, Setting s, int w) {
        if (s instanceof NumberSetting) return 30;
        if (s instanceof ModeSetting mo) return 15 + modeRows(tr, mo, w - 20) * 18 + 3;
        return 22;
    }

    private static int settingsHeight(TextRenderer tr, Module m, int w) {
        if (m.settings.isEmpty()) return 0;
        int h = 8;
        for (Setting s : m.settings) h += settingH(tr, s, w);
        return h;
    }

    // ------------------------------------------------------------ рендер
    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - last) / 1e9f);
        last = now;
        frameDt = dt;

        open.to(closing ? 0f : 1f, 12f, dt);
        if (closing && open.v < 0.03f) { client.setScreen(null); return; }
        float a = Draw.ease(open.v);

        TextRenderer tr = client.textRenderer;
        int acc = Theme.accent();
        var ui = ModuleManager.ui;

        if (ui.blur.get()) applyBlur();

        // фон: затемнение, холодный градиент, звёзды и мягкое свечение снизу
        ctx.fill(0, 0, width, height, Draw.argb(0x02040A, 0.55f * a));
        Draw.vgrad(ctx, 0, 0, width, height, Theme.BG_TOP, Theme.BG_BOTTOM, 0.5f * a);
        drawStars(ctx, a);
        for (int k = 6; k >= 1; k--)
            ctx.fill(0, height - k * 14, width, height - (k - 1) * 14, Draw.argb(acc, 0.012f * k * a));

        sideW = width >= 330 ? Math.min(116, width / 4) : 0;
        mainX = sideW > 0 ? sideW + 8 : 10;
        mainY = TOP + 4;
        mainW = Math.max(60, width - mainX - 10);
        mainH = Math.max(40, height - mainY - BOT - 4);

        if (sideW > 0) drawSidebar(ctx, tr, a, acc);
        drawTopBar(ctx, tr, a, acc, dt);
        drawBottomBar(ctx, tr, a, acc);

        if (searching && query.length() > 0) {
            layoutResults(tr);
            drawResults(ctx, tr, mouseX, mouseY, a, acc, dt);
        } else {
            layoutPanels(tr);
            drawPanels(ctx, tr, mouseX, mouseY, a, acc, dt);
        }
    }

    private void drawStars(DrawContext ctx, float a) {
        long t = System.currentTimeMillis();
        for (int i = 0; i < 90; i++) {
            int sx = (int) (rnd(i, 11) * width);
            int sy = (int) (rnd(i, 12) * height);
            float tw = 0.18f + 0.30f * (float) Math.abs(Math.sin(t / 1600.0 + i * 1.7));
            ctx.fill(sx, sy, sx + 1, sy + 1, Draw.argb(0xBFD3F5, tw * a));
        }
    }

    private void drawTopBar(DrawContext ctx, TextRenderer tr, float a, int acc, float dt) {
        Draw.rrect(ctx, 8, 5, 16, 16, 5, Draw.argb(acc, a));
        int lh = 12, lw = Logo.widthFor(lh);
        Logo.body(ctx, 8 + (16 - lw) / 2, 5 + (16 - lh) / 2, lw, lh, 0x061020, a);

        int tx = 30;
        Draw.text(ctx, tr, "SHTORA", tx, 9, acc, a);
        int off = tx + Draw.w(tr, "SHTORA");
        Draw.text(ctx, tr, " CLIENT", off, 9, Theme.TEXT, a);
        Draw.text(ctx, tr, " | v1.0", off + Draw.w(tr, " CLIENT"), 9, Theme.TEXT_DIM, a * 0.8f);

        searchAnim.to(searching ? 1f : 0f, 14f, dt);
        searchW = Math.min(150, Math.max(76, width / 3));
        searchH = 16;
        searchX = width - 10 - searchW;
        searchY = 5;
        Draw.rrect(ctx, searchX, searchY, searchW, searchH, 5,
                Draw.argb(Draw.mix(0x0A1220, acc, 0.18f * searchAnim.v), 0.9f * a));
        Draw.outline(ctx, searchX, searchY, searchW, searchH, 5,
                Draw.argb(Draw.mix(Theme.BORDER, acc, searchAnim.v), (0.8f + 0.2f * searchAnim.v) * a));

        int ic = Draw.mix(Theme.TEXT_DIM, acc, searchAnim.v);
        Draw.outline(ctx, searchX + 6, searchY + 4, 7, 7, 3, Draw.argb(ic, a));
        ctx.fill(searchX + 12, searchY + 10, searchX + 14, searchY + 12, Draw.argb(ic, a));

        String shown = searching ? Draw.trim(tr, query.toString(), searchW - 28) : "SEARCH";
        Draw.text(ctx, tr, shown, searchX + 18, searchY + 4, searching ? Theme.TEXT : Theme.TEXT_DIM, a);
        if (searching && (System.currentTimeMillis() / 500) % 2 == 0) {
            int cx = searchX + 18 + Draw.w(tr, shown);
            ctx.fill(cx + 1, searchY + 3, cx + 2, searchY + 13, Draw.argb(acc, a));
        }

        ctx.fill(0, TOP - 2, width, TOP - 1, Draw.argb(Theme.BORDER, 0.7f * a));
    }

    private void drawBottomBar(DrawContext ctx, TextRenderer tr, float a, int acc) {
        String hint = "ПРАВЫЙ SHIFT — ЗАКРЫТЬ";
        Draw.text(ctx, tr, hint, 10, height - BOT + 6, Theme.TEXT_DIM, a * 0.8f);

        String right = "";
        try {
            if (client.player != null) right = client.player.getName().getString();
            if (client.getNetworkHandler() != null && client.player != null) {
                var e = client.getNetworkHandler().getPlayerListEntry(client.player.getUuid());
                if (e != null) right += "   " + e.getLatency() + "ms";
            }
        } catch (Throwable ignored) {}
        if (!right.isEmpty())
            Draw.text(ctx, tr, right, width - 10 - Draw.w(tr, right), height - BOT + 6, Theme.TEXT_DIM, a * 0.8f);
    }

    // ------------------------------------------------------------ левая панель
    private void drawSidebar(DrawContext ctx, TextRenderer tr, float a, int acc) {
        int x = 6, w = sideW - 12;
        if (w < 60) return;
        Draw.rrect(ctx, x, mainY, w, mainH, 7, Draw.argb(Theme.SIDEBAR, 0.85f * a));
        Draw.outline(ctx, x, mainY, w, mainH, 7, Draw.argb(Theme.BORDER, 0.8f * a));

        int y = mainY + 8;
        int inner = w - 16;

        y = section(ctx, tr, "Keybinds", x + 8, y, inner, acc, a);
        for (Module m : ModuleManager.modules) {
            if (!m.isEnabled() || m == ModuleManager.ui) continue;
            if (y > mainY + mainH - 22) break;
            Draw.text(ctx, tr, Draw.trim(tr, m.name, inner - 4), x + 10, y, Theme.TEXT, a * 0.95f);
            ctx.fill(x + 10, y + 11, x + 15, y + 12, Draw.argb(acc, a));
            Draw.text(ctx, tr, "Active", x + 17, y + 10, Theme.TEXT_DIM, a * 0.8f);
            y += 22;
        }

        if (y > mainY + mainH - 60) return;
        y = section(ctx, tr, "Potions", x + 8, y + 4, inner, acc, a);
        try {
            if (client.player != null) {
                for (var e : client.player.getStatusEffects()) {
                    if (y > mainY + mainH - 22) break;
                    int secs = e.getDuration() / 20;
                    String nm = e.getEffectType().value().getName().getString();
                    Draw.text(ctx, tr, Draw.trim(tr, nm, inner - 34), x + 10, y, Theme.TEXT, a * 0.95f);
                    Draw.text(ctx, tr, secs / 60 + ":" + String.format(Locale.ROOT, "%02d", secs % 60),
                            x + 10, y + 11, acc, a * 0.85f);
                    y += 22;
                }
            }
        } catch (Throwable ignored) {}

        if (y > mainY + mainH - 60) return;
        y = section(ctx, tr, "Position", x + 8, y + 4, inner, acc, a);
        try {
            if (client.player != null) {
                var p = client.player.getBlockPos();
                Draw.text(ctx, tr, "X  " + p.getX(), x + 10, y, Theme.TEXT, a * 0.95f);
                Draw.text(ctx, tr, "Y  " + p.getY(), x + 10, y + 11, Theme.TEXT, a * 0.95f);
                Draw.text(ctx, tr, "Z  " + p.getZ(), x + 10, y + 22, Theme.TEXT, a * 0.95f);
            }
        } catch (Throwable ignored) {}
    }

    private int section(DrawContext ctx, TextRenderer tr, String title, int x, int y, int w, int acc, float a) {
        ctx.fill(x, y + 1, x + 3, y + 9, Draw.argb(acc, a));
        Draw.text(ctx, tr, title, x + 7, y, Theme.TEXT, a);
        ctx.fill(x, y + 14, x + w, y + 15, Draw.argb(Theme.BORDER, 0.6f * a));
        return y + 20;
    }

    // ------------------------------------------------------------ раскладка панелей
    private void layoutPanels(TextRenderer tr) {
        panels.clear();
        chips.clear();
        visible.clear();

        int cols = mainW >= 620 ? 3 : mainW >= 380 ? 2 : 1;
        int colW = (mainW - GAP * (cols - 1)) / cols;
        int[] colH = new int[cols];

        for (Category c : Category.values()) {
            List<Module> ms = ModuleManager.byCategory(c);
            if (ms.isEmpty()) continue;
            int iw = colW - 2 * PAD;
            int h = HEAD + PAD;
            for (Module m : ms)
                h += ROW + Math.round(m.expandAnim.v * (settingsHeight(tr, m, iw) + 4));
            h += PAD;

            int best = 0;
            for (int i = 1; i < cols; i++) if (colH[i] < colH[best]) best = i;

            Panel p = new Panel();
            p.cat = c;
            p.w = colW;
            p.h = h;
            p.x = mainX + best * (colW + GAP);
            p.y = mainY + colH[best];
            panels.add(p);
            colH[best] += h + GAP;
        }

        contentH = 0f;
        for (int v : colH) contentH = Math.max(contentH, v);
        maxScroll = Math.max(0f, contentH - mainH);
        scrollTarget = Math.max(0f, Math.min(maxScroll, scrollTarget));
        scroll.to(scrollTarget, 22f, frameDt);
    }

    private void drawPanels(DrawContext ctx, TextRenderer tr, int mouseX, int mouseY, float a, int acc, float dt) {
        ctx.enableScissor(0, mainY, width, mainY + mainH);
        for (Panel p : panels) {
            int px = p.x;
            int py = Math.round(p.y - scroll.v);

            Draw.rrect(ctx, px, py, p.w, p.h, 7, Draw.argb(Theme.CARD, 0.82f * a));
            Draw.outline(ctx, px, py, p.w, p.h, 7, Draw.argb(Theme.BORDER, 0.75f * a));
            Draw.rrect(ctx, px + 1, py + 1, p.w - 2, HEAD - 2, 6, Draw.argb(Theme.CARD_HEAD, 0.85f * a));
            ctx.fill(px + 1, py + HEAD - 1, px + p.w - 1, py + HEAD, Draw.argb(Theme.BORDER, 0.55f * a));
            ctx.fill(px + 8, py + 7, px + 11, py + HEAD - 5, Draw.argb(acc, a));
            Draw.text(ctx, tr, p.cat.title, px + 16, py + 7, Theme.TEXT, a);

            int y = py + HEAD + PAD / 2;
            int iw = p.w - 2 * PAD;
            for (Module m : ModuleManager.byCategory(p.cat)) {
                m.uiX = px + PAD;
                m.uiY = y;
                m.uiW = iw;
                m.uiH = ROW + Math.round(m.expandAnim.v * (settingsHeight(tr, m, iw) + 4));
                m.toggleAnim.to(m.isEnabled() ? 1f : 0f, 14f, dt);
                m.expandAnim.to(m.expanded && !m.settings.isEmpty() ? 1f : 0f, 14f, dt);

                boolean hov = mouseX >= m.uiX && mouseX < m.uiX + iw
                        && mouseY >= y && mouseY < y + ROW
                        && mouseY >= mainY && mouseY < mainY + mainH;
                m.hoverAnim.to(hov ? 1f : 0f, 16f, dt);

                if (y + m.uiH >= mainY && y <= mainY + mainH)
                    drawRow(ctx, tr, m, m.uiX, y, iw, m.uiH, a, acc, dt);
                visible.add(m);
                y += m.uiH;
            }
        }
        ctx.disableScissor();
        scrollbar(ctx, a, acc);
    }

    private void drawResults(DrawContext ctx, TextRenderer tr, int mouseX, int mouseY, float a, int acc, float dt) {
        ctx.enableScissor(0, mainY, width, mainY + mainH);
        if (results.isEmpty()) {
            String s = "Ничего не найдено";
            Draw.text(ctx, tr, s, mainX + (mainW - Draw.w(tr, s)) / 2, mainY + mainH / 2 - 4, Theme.TEXT_DIM, a);
        }
        for (Module m : results) {
            int y = Math.round(m.uiY - scroll.v);
            m.uiY = y;
            m.toggleAnim.to(m.isEnabled() ? 1f : 0f, 14f, dt);
            m.expandAnim.to(m.expanded && !m.settings.isEmpty() ? 1f : 0f, 14f, dt);
            boolean hov = mouseX >= m.uiX && mouseX < m.uiX + m.uiW
                    && mouseY >= y && mouseY < y + ROW
                    && mouseY >= mainY && mouseY < mainY + mainH;
            m.hoverAnim.to(hov ? 1f : 0f, 16f, dt);
            if (y + m.uiH >= mainY && y <= mainY + mainH)
                drawRow(ctx, tr, m, m.uiX, y, m.uiW, m.uiH, a, acc, dt);
        }
        ctx.disableScissor();
        scrollbar(ctx, a, acc);
    }

    private void scrollbar(DrawContext ctx, float a, int acc) {
        if (maxScroll > 0.5f) {
            int sbh = Math.max(16, Math.round(mainH * mainH / contentH));
            int sby = mainY + Math.round((mainH - sbh) * (scroll.v / maxScroll));
            ctx.fill(width - 3, sby, width - 1, sby + sbh, Draw.argb(acc, 0.6f * a));
        }
    }

    private void layoutResults(TextRenderer tr) {
        panels.clear();
        chips.clear();
        visible.clear();
        results.clear();

        String q = query.toString().toLowerCase(Locale.ROOT);
        for (Module m : ModuleManager.modules)
            if (m.name.toLowerCase(Locale.ROOT).contains(q)) results.add(m);

        int y = mainY;
        for (Module m : results) {
            m.uiX = mainX;
            m.uiY = y;
            m.uiW = mainW;
            m.uiH = ROW + Math.round(m.expandAnim.v * (settingsHeight(tr, m, mainW - 2 * PAD) + 4));
            y += m.uiH + 4;
            visible.add(m);
        }
        contentH = y - mainY;
        maxScroll = Math.max(0f, contentH - mainH);
        scrollTarget = Math.max(0f, Math.min(maxScroll, scrollTarget));
        scroll.to(scrollTarget, 22f, frameDt);
    }

    // ------------------------------------------------------------ строка модуля
    private void drawRow(DrawContext ctx, TextRenderer tr, Module m, int x, int y, int w, int h,
                         float a, int acc, float dt) {
        float tg = m.toggleAnim.v;
        int bg = Draw.mix(Theme.CARD, acc, 0.12f * tg);
        Draw.rrect(ctx, x, y, w, ROW, 6, Draw.argb(Draw.mix(bg, 0xFFFFFF, 0.03f * m.hoverAnim.v), 0.95f * a));
        Draw.outline(ctx, x, y, w, ROW, 6, Draw.argb(Draw.mix(Theme.BORDER, acc, 0.5f * tg), (0.7f + 0.3f * tg) * a));

        int barH = Math.round(ROW * tg);
        if (barH > 0) Draw.rrect(ctx, x, y, 3, barH, 2, Draw.argb(acc, a));

        int tx = x + 10;
        if (!m.settings.isEmpty()) {
            tx = x + 19;
            int cx = x + 10, cy = y + ROW / 2;
            int cc = Draw.argb(Draw.mix(Theme.TEXT_DIM, acc, m.expandAnim.v), a);
            if (m.expandAnim.v < 0.5f) {
                Draw.line(ctx, cx, cy - 3, cx + 3, cy, cc);
                Draw.line(ctx, cx + 3, cy, cx, cy + 3, cc);
            } else {
                Draw.line(ctx, cx - 1, cy - 2, cx + 2, cy + 1, cc);
                Draw.line(ctx, cx + 2, cy + 1, cx + 5, cy - 2, cc);
            }
        }

        int maxText = w - (tx - x) - 42;
        Draw.text(ctx, tr, Draw.trim(tr, m.name, maxText), tx, y + 6,
                Draw.mix(Theme.TEXT_DIM, 0xFFFFFF, tg), a);
        if (!m.description.isEmpty())
            Draw.text(ctx, tr, Draw.trim(tr, m.description, maxText), tx, y + 16, Theme.DESC, a * 0.92f);

        pill(ctx, x + w - 34, y + (ROW - 13) / 2, 24, 13, tg, acc, a);

        if (m.expandAnim.v > 0.02f) drawSettings(ctx, tr, m, x, y, w, h, a, acc, dt);
    }

    private static void pill(DrawContext ctx, int x, int y, int w, int h, float on, int acc, float a) {
        Draw.rrect(ctx, x, y, w, h, h / 2, Draw.argb(Draw.mix(Theme.TOGGLE_OFF, acc, on), (0.9f + 0.1f * on) * a));
        Draw.outline(ctx, x, y, w, h, h / 2, Draw.argb(Draw.mix(Theme.BORDER, acc, on), a));
        int k = h - 4;
        int kx = x + 2 + Math.round(on * (w - k - 4));
        Draw.rrect(ctx, kx, y + 2, k, k, k / 2, Draw.argb(Draw.mix(0xB9C4D4, 0xFFFFFF, on), a));
    }

    /** Скруглённый чекбокс с галочкой (для булевых настроек). */
    private static void checkbox(DrawContext ctx, int x, int y, int s, float on, int acc, float a) {
        Draw.rrect(ctx, x, y, s, s, 3, Draw.argb(Draw.mix(0x16203A, acc, on), 0.95f * a));
        Draw.outline(ctx, x, y, s, s, 3, Draw.argb(Draw.mix(Theme.BORDER, acc, on), (0.8f + 0.2f * on) * a));
        if (on > 0.05f) {
            int col = Draw.argb(0xFFFFFF, on * a);
            Draw.line(ctx, x + 3, y + s / 2, x + s / 2 - 1, y + s - 4, col);
            Draw.line(ctx, x + s / 2 - 1, y + s - 4, x + s - 3, y + 4, col);
        }
    }

    private void drawSettings(DrawContext ctx, TextRenderer tr, Module m, int x, int y, int w, int h,
                              float a, int acc, float dt) {
        ctx.enableScissor(x, Math.max(y, mainY), x + w, Math.min(y + h, mainY + mainH));
        float ea = a * m.expandAnim.v;
        ctx.fill(x + 8, y + ROW, x + w - 8, y + ROW + 1, Draw.argb(Theme.BORDER, 0.85f * ea));
        int ry = y + ROW + 5;
        for (Setting s : m.settings) {
            int sh = settingH(tr, s, w);
            s.ux = x; s.uy = ry; s.uw = w; s.uh = sh;
            if (s instanceof BoolSetting b) {
                b.anim.to(b.get() ? 1f : 0f, 16f, dt);
                Draw.text(ctx, tr, Draw.trim(tr, b.name, w - 46), x + 10, ry + 6, Theme.TEXT, ea);
                checkbox(ctx, x + w - 24, ry + 4, 12, b.anim.v, acc, ea);
            } else if (s instanceof NumberSetting n) {
                n.ux = x + 10; n.uw = w - 20;
                n.anim.to(n.frac(), 22f, dt);
                String vs = n.step >= 1 ? String.valueOf((int) Math.round(n.get()))
                        : String.format(Locale.ROOT, "%.2f", n.get());
                Draw.text(ctx, tr, n.name, x + 10, ry + 2, Theme.TEXT, ea);
                Draw.text(ctx, tr, vs, x + w - 10 - Draw.w(tr, vs), ry + 2, acc, ea);
                int fw = Math.round(n.anim.v * n.uw);
                Draw.rrect(ctx, n.ux, ry + 19, n.uw, 4, 2, Draw.argb(0x000000, 0.35f * ea));
                Draw.rrect(ctx, n.ux, ry + 19, Math.max(1, fw), 4, 2, Draw.argb(acc, ea));
                Draw.rrect(ctx, n.ux + fw - 5, ry + 16, 10, 10, 5, Draw.argb(acc, ea));
                Draw.rrect(ctx, n.ux + fw - 3, ry + 18, 6, 6, 3, Draw.argb(0xFFFFFF, ea));
            } else if (s instanceof ModeSetting mo) {
                Draw.text(ctx, tr, mo.name, x + 10, ry + 2, Theme.TEXT, ea);
                int cxp = x + 10, cyp = ry + 15;
                for (int i = 0; i < mo.modes.length; i++) {
                    int tw = Draw.w(tr, mo.modes[i]) + 12;
                    if (cxp + tw > x + w - 10 && cxp > x + 10) { cxp = x + 10; cyp += 18; }
                    boolean sel = i == mo.index();
                    Draw.rrect(ctx, cxp, cyp, tw, 15, 4, Draw.argb(sel ? acc : 0x16203A, (sel ? 0.9f : 0.85f) * ea));
                    Draw.outline(ctx, cxp, cyp, tw, 15, 4, Draw.argb(sel ? acc : Theme.BORDER, ea));
                    Draw.text(ctx, tr, mo.modes[i], cxp + 6, cyp + 4, sel ? 0x0B0E12 : Theme.TEXT_DIM, ea);
                    Chip c = new Chip();
                    c.mo = mo; c.idx = i; c.x = cxp; c.y = cyp; c.w = tw; c.h = 15;
                    chips.add(c);
                    cxp += tw + 4;
                }
            }
            ry += sh;
        }
        ctx.disableScissor();
    }

    // ------------------------------------------------------------ ввод
    private static boolean in(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private void setSlider(NumberSetting s, double mx) {
        double f = Math.max(0.0, Math.min(1.0, (mx - s.ux) / (double) s.uw));
        double raw = s.min + f * (s.max - s.min);
        s.set(Math.round(raw / s.step) * s.step);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (open.v < 0.9f || closing) return true;

        // шапка: поле поиска
        if (my >= 2 && my < TOP) {
            if (in(mx, my, searchX, searchY, searchW, searchH)) { searching = true; return true; }
            if (searching) stopSearch();
            return true;
        }
        if (my < mainY || my > mainY + mainH) return true;

        // слайдеры раскрытых модулей
        for (Module m : visible) {
            if (m.expandAnim.v < 0.6f) continue;
            for (Setting s : m.settings) {
                if (s instanceof NumberSetting n
                        && in(mx, my, n.ux - 6, n.uy + 14, n.uw + 12, 16)
                        && in(mx, my, m.uiX, m.uiY, m.uiW, m.uiH)) {
                    dragSlider = n;
                    setSlider(n, mx);
                    return true;
                }
            }
        }

        pressArea = 1;
        pressX = mx; pressY = my; moved = 0;
        return true;
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragSlider != null) { setSlider(dragSlider, mx); return true; }
        if (pressArea == 1) {
            moved += Math.abs(dx) + Math.abs(dy);
            scrollTarget = Math.max(0f, Math.min(maxScroll, scrollTarget - (float) dy));
        }
        return true;
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (dragSlider != null) { dragSlider = null; return true; }
        int area = pressArea;
        pressArea = 0;
        if (area == 1 && moved < 6) tap(pressX, pressY);
        return true;
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double h, double v) {
        scrollTarget = Math.max(0f, Math.min(maxScroll, scrollTarget - (float) v * 22f));
        return true;
    }

    private void tap(double mx, double my) {
        for (Module m : visible) {
            if (!in(mx, my, m.uiX, m.uiY, m.uiW, m.uiH)) continue;
            if (my < m.uiY + ROW) {
                if (!m.settings.isEmpty() && mx >= m.uiX + 5 && mx < m.uiX + 17) {
                    m.expanded = !m.expanded;
                    return;
                }
                m.toggle();
                return;
            }
            if (m.expandAnim.v > 0.6f) {
                for (Chip c : chips)
                    if (in(mx, my, c.x, c.y, c.w, c.h)) { c.mo.set(c.idx); return; }
                for (Setting s : m.settings)
                    if (s instanceof BoolSetting b && in(mx, my, b.ux, b.uy, b.uw, b.uh)) { b.toggle(); return; }
            }
            return;
        }
    }

    /** Устойчивое псевдослучайное число 0..1 (для звёзд фона). */
    private static float rnd(int i, int salt) {
        int x = i * 374761393 + salt * 668265263;
        x = (x ^ (x >> 13)) * 1274126177;
        x ^= (x >> 16);
        return (x & 0x7FFFFFFF) / (float) 0x7FFFFFFF;
    }
}
