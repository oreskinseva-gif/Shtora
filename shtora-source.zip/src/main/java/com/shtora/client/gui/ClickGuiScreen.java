package com.shtora.client.gui;

import com.shtora.client.Category;
import com.shtora.client.Module;
import com.shtora.client.ModuleManager;
import com.shtora.client.setting.BoolSetting;
import com.shtora.client.setting.ModeSetting;
import com.shtora.client.setting.NumberSetting;
import com.shtora.client.setting.Setting;
import com.shtora.client.util.Anim;
import com.shtora.client.util.Draw;
import com.shtora.client.util.Logo;
import com.shtora.client.util.Theme;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Меню клиента (правый Shift).
 *
 * Модули лежат в папках (Combat, Movement, Player, ...). Папку можно:
 *  - открыть правой кнопкой мыши (или вторым кликом левой) — появятся модули;
 *  - перетащить, удерживая за шапку;
 *  - выделить левой кнопкой — появятся две кнопки: ★ избранное и 🗑 удалить.
 *
 * Удалённая папка не исчезает, а подсвечивается жёлтым; вернуть её можно там же
 * (кнопка «вернуть») или во вкладке «Удалённые». Сверху фильтры:
 * ВСЕ (без удалённых), ИЗБРАННОЕ и УДАЛЁННЫЕ.
 */
public class ClickGuiScreen extends Screen {
    // ------------------------------------------------------------------ геометрия
    private static final int TOP = 26, BOT = 20;      // верхняя и нижняя полосы
    private static final int ROW = 28, HEAD = 26;     // строка модуля и шапка папки
    private static final int PAD = 6, GAP = 6, TAB = 20;

    // ------------------------------------------------------------------ состояние папок
    /** Порядок папок (меняется перетаскиванием), избранное и удалённое — живут между открытиями меню. */
    private static final List<Category> ORDER = new ArrayList<>(List.of(Category.values()));
    private static final Set<Category> FAV = EnumSet.noneOf(Category.class);
    private static final Set<Category> DEL = EnumSet.noneOf(Category.class);
    private static final Map<Category, Boolean> OPENED = new EnumMap<>(Category.class);
    private static int filter;                        // 0 — все, 1 — избранное, 2 — удалённые

    // ------------------------------------------------------------------ анимации и раскладка
    private final Anim open = new Anim(0), scroll = new Anim(0);
    private final Map<Category, Anim> hoverA = new EnumMap<>(Category.class);
    private final Map<Category, Anim> openA = new EnumMap<>(Category.class);
    private final Map<Category, Anim> starA = new EnumMap<>(Category.class);
    private final Map<Category, Anim> trashA = new EnumMap<>(Category.class);
    private final Map<Category, float[]> box = new EnumMap<>(Category.class);
    private final Map<Category, List<Module>> byCat = new EnumMap<>(Category.class);

    private static final class Chip {
        ModeSetting mo; int idx, x, y, w, h;
    }

    private final List<Chip> chips = new ArrayList<>();
    private final List<Module> visible = new ArrayList<>();
    private final List<Module> results = new ArrayList<>();
    private final StringBuilder query = new StringBuilder();

    private boolean closing, searching;
    private float scrollTarget, maxScroll, contentH, frameDt = 0.016f;
    private long last = System.nanoTime();

    private int listX, listY, listW, listH;
    private int tabY, tabH;
    private int searchX, searchY, searchW, searchH;

    private int pressArea;                            // 0 — ничего, 1 — фон, 2 — папка
    private double pressX, pressY;
    private float moved;
    private boolean pressWasSelected;
    private NumberSetting dragSlider;
    private Category dragCat, selected;
    private float dragGrabY, dragCurY;

    public ClickGuiScreen() {
        super(Text.empty());
    }

    @Override public boolean shouldPause() { return false; }
    @Override public void close() { closing = true; }
    @Override public void renderBackground(DrawContext ctx, int mx, int my, float delta) {}

    // ------------------------------------------------------------------ клавиатура
    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (searching) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE) { stopSearch(); return true; }
            if (keyCode == GLFW.GLFW_KEY_BACKSPACE) {
                if (query.length() > 0) query.setLength(query.length() - 1);
                return true;
            }
        }
        if (keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT && !searching) { close(); return true; }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (searching && chr >= 32 && query.length() < 24) {
            query.append(chr);
            scrollTarget = 0f;
            return true;
        }
        return super.charTyped(chr, modifiers);
    }

    private void stopSearch() { searching = false; query.setLength(0); }

    private static Anim anim(Map<Category, Anim> m, Category c) {
        return m.computeIfAbsent(c, k -> new Anim(0));
    }

    private static boolean isOpen(Category c) { return Boolean.TRUE.equals(OPENED.get(c)); }

    private static void toggleOpen(Category c) { OPENED.put(c, !isOpen(c)); }

    private static boolean matches(Category c) {
        if (filter == 2) return DEL.contains(c);
        if (DEL.contains(c)) return false;            // в «Все» и «Избранном» удалённых нет
        if (filter == 1) return FAV.contains(c);
        return true;
    }

    private static int enabled(Category c) {
        int n = 0;
        for (Module m : ModuleManager.byCategory(c)) if (m.isEnabled()) n++;
        return n;
    }

    // ------------------------------------------------------------------ рендер
    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - last) / 1e9f);
        last = now;
        frameDt = dt;

        open.to(closing ? 0f : 1f, 12f, dt);
        if (closing && open.v < 0.03f) { client.setScreen(null); return; }
        float a = Draw.ease(open.v);

        TextRenderer tr = client.textRenderer;
        int acc = Theme.accent();
        var ui = ModuleManager.ui;
        if (ui.blur.get()) applyBlur();

        float t = System.currentTimeMillis() / 1000f;
        drawBackground(ctx, a, t);

        listX = 10;
        listW = Math.max(80, width - 20);
        listY = TOP + TAB + 8;
        listH = Math.max(40, height - listY - BOT - 4);
        tabY = TOP + 4;
        tabH = TAB;

        for (Category c : ORDER) {
            byCat.put(c, ModuleManager.byCategory(c));
            anim(openA, c).to(isOpen(c) ? 1f : 0f, 14f, dt);
            anim(starA, c).to(FAV.contains(c) ? 1f : 0f, 16f, dt);
            anim(trashA, c).to(DEL.contains(c) ? 1f : 0f, 16f, dt);
        }

        drawTopBar(ctx, tr, a, acc, dt);
        drawTabs(ctx, tr, a, acc);

        chips.clear();
        visible.clear();
        if (searching && query.length() > 0) {
            layoutResults(tr);
            drawResults(ctx, tr, mouseX, mouseY, a, acc, dt);
        } else {
            layoutFolders(tr);
            drawFolders(ctx, tr, mouseX, mouseY, a, acc, dt);
        }
        drawBottomBar(ctx, tr, a, acc);
    }

    // ------------------------------------------------------------------ фон
    private void drawBackground(DrawContext ctx, float a, float t) {
        int bands = 48;
        for (int i = 0; i < bands; i++) {
            float u0 = i / (float) bands, u1 = (i + 1) / (float) bands;
            ctx.fillGradient(0, Math.round(height * u0), width, Math.round(height * u1) + 1,
                    Draw.argb(Theme.sky(u0, t), a), Draw.argb(Theme.sky(u1, t), a));
        }

        // звёзды
        for (int i = 0; i < 80; i++) {
            int sx = (int) (rnd(i, 11) * width);
            int sy = (int) (rnd(i, 12) * height);
            float tw = 0.15f + 0.35f * (float) Math.abs(Math.sin(t * 0.7 + i * 1.7));
            ctx.fill(sx, sy, sx + 1, sy + 1, Draw.argb(0xCFE7FF, tw * a));
        }

        // мягкое свечение снизу
        int glow = Math.max(20, height / 5);
        Draw.vgrad(ctx, 0, height - glow, width, glow, Theme.SKY_DARK, Theme.SKY_GLOW, 0.16f * a);
    }

    // ------------------------------------------------------------------ верх и низ
    private void drawTopBar(DrawContext ctx, TextRenderer tr, float a, int acc, float dt) {
        Draw.glow(ctx, 8, 5, 16, 16, 5, acc, a * 0.5f);
        Draw.rrect(ctx, 8, 5, 16, 16, 5, Draw.argb(acc, a));
        int lh = 12, lw = Logo.widthFor(lh);
        Logo.body(ctx, 8 + (16 - lw) / 2, 5 + (16 - lh) / 2, lw, lh, 0x061020, a);

        int wx = 30, ww = Logo.wordWidthFor(12);
        if (ww > 0) {
            Draw.glow(ctx, wx - 2, 6, ww + 4, 16, 4, acc, a * 0.35f);
            Logo.word(ctx, wx, 7, ww, 12, Theme.TEXT, a);
            Draw.text(ctx, tr, "CLIENT", wx + ww + 5, 9, acc, a);
        } else {
            Draw.gothic(ctx, tr, "SHTORA", wx, 9, Theme.TEXT, a);
            Draw.text(ctx, tr, "CLIENT", wx + Draw.gw(tr, "SHTORA") + 5, 9, acc, a);
        }

        searchW = Math.min(150, Math.max(72, width / 3));
        searchH = 16;
        searchX = width - 10 - searchW;
        searchY = 5;
        Draw.rrect(ctx, searchX, searchY, searchW, searchH, 5,
                Draw.argb(Draw.mix(0x0A1220, acc, 0.18f), 0.9f * a));
        Draw.outline(ctx, searchX, searchY, searchW, searchH, 5,
                Draw.argb(Draw.mix(Theme.BORDER, acc, searching ? 1f : 0.2f), a));

        int ic = Draw.mix(Theme.TEXT_DIM, acc, searching ? 1f : 0f);
        Draw.outline(ctx, searchX + 6, searchY + 4, 7, 7, 3, Draw.argb(ic, a));
        ctx.fill(searchX + 12, searchY + 10, searchX + 14, searchY + 12, Draw.argb(ic, a));

        String shown = searching ? Draw.trim(tr, query.toString(), searchW - 30) : "SEARCH";
        Draw.text(ctx, tr, shown, searchX + 18, searchY + 4, searching ? Theme.TEXT : Theme.TEXT_DIM, a);
        if (searching && (System.currentTimeMillis() / 500) % 2 == 0) {
            int cx = searchX + 18 + Draw.w(tr, shown);
            ctx.fill(cx + 1, searchY + 3, cx + 2, searchY + 13, Draw.argb(acc, a));
        }

        ctx.fill(0, TOP - 2, width, TOP - 1, Draw.argb(Theme.BORDER, 0.7f * a));
    }

    private int tabW() { return (width - 20 - GAP * 2) / 3; }

    private void drawTabs(DrawContext ctx, TextRenderer tr, float a, int acc) {
        String[] names = {"ВСЕ", "ИЗБРАННОЕ", "УДАЛЁННЫЕ"};
        for (int i = 0; i < 3; i++) {
            int x = 10 + i * (tabW() + GAP);
            boolean sel = filter == i;
            int rgb = i == 2 ? Theme.DELETED : i == 1 ? Theme.STAR : acc;
            Draw.rrect(ctx, x, tabY, tabW(), tabH, 5,
                    Draw.argb(sel ? Draw.mix(Theme.FOLDER, rgb, 0.30f) : Theme.FOLDER, (sel ? 0.95f : 0.75f) * a));
            Draw.outline(ctx, x, tabY, tabW(), tabH, 5,
                    Draw.argb(sel ? rgb : Theme.BORDER, (sel ? 1f : 0.7f) * a));
            String label = Draw.trim(tr, names[i], tabW() - 10);
            Draw.text(ctx, tr, label, x + (tabW() - Draw.w(tr, label)) / 2, tabY + 6,
                    sel ? rgb : Theme.TEXT_DIM, a);
        }
    }

    private void drawBottomBar(DrawContext ctx, TextRenderer tr, float a, int acc) {
        Draw.text(ctx, tr, "ПКМ — открыть папку   ЛКМ — выбрать", 10, height - BOT + 6, Theme.TEXT_DIM, a * 0.8f);
        String right = "";
        try {
            if (client.player != null) right = client.player.getName().getString();
            if (client.getNetworkHandler() != null && client.player != null) {
                var e = client.getNetworkHandler().getPlayerListEntry(client.player.getUuid());
                if (e != null) right += "   " + e.getLatency() + "ms";
            }
        } catch (Throwable ignored) {}
        if (!right.isEmpty())
            Draw.text(ctx, tr, right, width - 10 - Draw.w(tr, right), height - BOT + 6, Theme.TEXT_DIM, a * 0.8f);
    }

    // ------------------------------------------------------------------ раскладка папок
    private float bodyHeight(TextRenderer tr, Category c) {
        float h = 4f;
        for (Module m : byCat.getOrDefault(c, ModuleManager.byCategory(c)))
            h += ROW + Math.round(m.expandAnim.v * (settingsHeight(tr, m, listW - 2 * PAD) + 4));
        return h;
    }

    private void layoutFolders(TextRenderer tr) {
        box.clear();
        float total = 0f;
        Map<Category, Float> hs = new HashMap<>();
        for (Category c : ORDER) {
            if (!matches(c)) continue;
            float h = HEAD + PAD + bodyHeight(tr, c) * anim(openA, c).v;
            hs.put(c, h);
            total += h + GAP;
        }
        contentH = total;
        maxScroll = Math.max(0f, contentH - listH);
        scrollTarget = Math.max(0f, Math.min(maxScroll, scrollTarget));
        scroll.to(scrollTarget, 22f, frameDt);

        float y = listY - scroll.v;
        for (Category c : ORDER) {
            if (!matches(c)) continue;
            float h = hs.getOrDefault(c, (float) HEAD);
            box.put(c, new float[]{listX, y, listW, h});
            y += h + GAP;
        }
    }

    private void drawFolders(DrawContext ctx, TextRenderer tr, int mouseX, int mouseY,
                             float a, int acc, float dt) {
        ctx.enableScissor(0, listY, width, listY + listH);
        for (Category c : ORDER) {
            if (!matches(c)) continue;
            float[] r = box.get(c);
            if (r == null) continue;
            float y = r[1];
            boolean lifted = dragCat == c && moved > 5f;
            if (lifted) y = dragCurY - dragGrabY;
            if (y + r[3] < listY - 4 || y > listY + listH + 4) continue;
            drawFolder(ctx, tr, c, r[0], y, r[2], r[3], mouseX, mouseY, a, acc, dt, lifted);
        }
        ctx.disableScissor();
        scrollbar(ctx, a, acc);
    }

    private void scrollbar(DrawContext ctx, float a, int acc) {
        if (maxScroll > 0.5f) {
            int sbh = Math.max(16, Math.round(listH * listH / Math.max(1f, contentH)));
            int sby = listY + Math.round((listH - sbh) * (scroll.v / maxScroll));
            Draw.rrect(ctx, width - 3, sby, 2, sbh, 1, Draw.argb(acc, 0.7f * a));
        }
    }

    // ------------------------------------------------------------------ папка
    private void drawFolder(DrawContext ctx, TextRenderer tr, Category c, float fx, float fy, float fw, float fh,
                            int mx, int my, float a, int acc, float dt, boolean lifted) {
        int x = Math.round(fx), y = Math.round(fy), w = Math.round(fw), h = Math.round(fh);
        boolean hov = !lifted && my >= y && my < y + HEAD && my >= listY && my < listY + listH
                && mx >= x && mx < x + w;
        Anim ha = anim(hoverA, c);
        ha.to(hov ? 1f : 0f, 16f, dt);

        boolean deleted = DEL.contains(c);
        boolean fav = FAV.contains(c);
        boolean sel = selected == c && !lifted;
        float oa = anim(openA, c).v;

        int bg = Draw.mix(Theme.FOLDER, Theme.FOLDER_OPEN, oa);
        if (deleted) bg = Draw.mix(bg, Theme.DELETED, 0.15f);
        else if (fav) bg = Draw.mix(bg, Theme.STAR, 0.07f);
        if (hov) bg = Draw.mix(bg, 0xFFFFFF, 0.04f);
        if (sel) bg = Draw.mix(bg, acc, 0.12f);

        int edge = deleted ? Theme.DELETED : fav ? Draw.mix(Theme.BORDER, Theme.STAR, 0.55f) : sel ? acc : Theme.BORDER;
        if (sel || fav || deleted || lifted)
            Draw.glow(ctx, x, y, w, h, 8, deleted ? Theme.DELETED : fav ? Theme.STAR : acc,
                    a * (lifted ? 0.65f : 0.40f));

        Draw.rrect(ctx, x, y, w, h, 8, Draw.argb(bg, 0.94f * a));
        Draw.outline(ctx, x, y, w, h, 8, Draw.argb(edge, (0.75f + 0.25f * ha.v) * a));
        Draw.rrect(ctx, x + 1, y + 1, 3, HEAD - 2, 2, Draw.argb(deleted ? Theme.DELETED : acc, a));

        // заголовок и счётчик
        int rightPad = 62;
        String title = Draw.trim(tr, c.title, w - rightPad - 18);
        Draw.text(ctx, tr, title, x + 12, y + 9, deleted ? Theme.DELETED : Theme.TEXT, a);
        List<Module> ms = byCat.getOrDefault(c, ModuleManager.byCategory(c));
        int on = 0;
        for (Module m : ms) if (m.isEnabled()) on++;
        Draw.text(ctx, tr, on + "/" + ms.size(), x + 12 + Draw.w(tr, title) + 6, y + 9, Theme.TEXT_DIM, a * 0.8f);

        int cy = y + HEAD / 2;
        int chevX = x + w - 14;
        chevron(ctx, chevX, cy, oa, deleted ? Theme.DELETED : acc, a);

        if (sel) {
            // две кнопки: избранное и удаление (или возврат)
            int trashX = x + w - 46, starX = x + w - 30;
            button(ctx, tr, starX, cy - 8, Theme.STAR, FAV.contains(c), anim(starA, c).v, a);
            iconStar(ctx, starX + 8, cy, 5, Draw.argb(FAV.contains(c) ? Theme.STAR : Theme.TEXT_DIM, a));

            boolean rest = deleted;
            button(ctx, tr, trashX, cy - 8, rest ? Theme.RESTORE : Theme.TRASH, rest, anim(trashA, c).v, a);
            if (rest) iconRestore(ctx, trashX + 8, cy, 5, Draw.argb(Theme.RESTORE, a));
            else iconTrash(ctx, trashX + 8, cy, 5, Draw.argb(Theme.TRASH, a));
        } else if (fav || deleted) {
            int bx = x + w - 22;
            if (fav) iconStar(ctx, bx + 8, cy, 4, Draw.argb(Theme.STAR, a * 0.95f));
            if (deleted) iconTrash(ctx, bx + 8, cy, 4, Draw.argb(Theme.DELETED, a * 0.95f));
        }

        // содержимое папки
        if (oa > 0.02f) {
            int innerX = x + PAD, innerW = w - 2 * PAD;
            int bodyTop = y + HEAD + 2;
            ctx.enableScissor(x, Math.max(y + HEAD, listY), x + w, Math.min(y + h, listY + listH));
            int ry = bodyTop + 2;
            for (Module m : ms) {
                m.uiX = innerX;
                m.uiY = ry;
                m.uiW = innerW;
                m.uiH = ROW + Math.round(m.expandAnim.v * (settingsHeight(tr, m, innerW) + 4));
                m.toggleAnim.to(m.isEnabled() ? 1f : 0f, 14f, dt);
                m.expandAnim.to(m.expanded && !m.settings.isEmpty() ? 1f : 0f, 14f, dt);

                boolean mh = mx >= innerX && mx < innerX + innerW && my >= ry && my < ry + ROW
                        && my >= listY && my < listY + listH;
                m.hoverAnim.to(mh ? 1f : 0f, 16f, dt);
                visible.add(m);

                if (ry + m.uiH >= listY && ry <= listY + listH)
                    drawRow(ctx, tr, m, innerX, ry, innerW, m.uiH, a * oa, acc, dt);
                ry += m.uiH;
            }
            ctx.disableScissor();
        }
    }

    private static void button(DrawContext ctx, TextRenderer tr, int x, int y, int rgb, boolean on, float anim, float a) {
        Draw.rrect(ctx, x, y, 16, 16, 5, Draw.argb(Draw.mix(Theme.FOLDER, rgb, 0.18f + 0.22f * anim), 0.95f * a));
        Draw.outline(ctx, x, y, 16, 16, 5, Draw.argb(Draw.mix(Theme.BORDER, rgb, on ? 1f : 0.35f), a));
    }

    private static void chevron(DrawContext ctx, int cx, int cy, float oa, int rgb, float a) {
        int col = Draw.argb(rgb, a);
        if (oa < 0.5f) {
            Draw.line(ctx, cx - 3, cy - 2, cx, cy + 1, col);
            Draw.line(ctx, cx, cy + 1, cx + 3, cy - 2, col);
        } else {
            Draw.line(ctx, cx - 3, cy + 1, cx, cy - 2, col);
            Draw.line(ctx, cx, cy - 2, cx + 3, cy + 1, col);
        }
    }

    /** Четырёхлучевая звёздочка (избранное). */
    private static void iconStar(DrawContext ctx, int cx, int cy, int r, int color) {
        for (int i = 0; i <= r; i++) {
            int t = Math.max(1, (r - i) / 2 + 1);
            ctx.fill(cx + i, cy - t, cx + i + 1, cy + t + 1, color);
            ctx.fill(cx - i, cy - t, cx - i + 1, cy + t + 1, color);
            ctx.fill(cx - t, cy + i, cx + t + 1, cy + i + 1, color);
            ctx.fill(cx - t, cy - i, cx + t + 1, cy - i + 1, color);
        }
    }

    private static void iconTrash(DrawContext ctx, int cx, int cy, int r, int color) {
        ctx.fill(cx - r, cy - r + 1, cx + r + 1, cy - r + 3, color);      // крышка
        ctx.fill(cx - 1, cy - r - 1, cx + 2, cy - r + 1, color);          // ручка
        ctx.fill(cx - r + 1, cy - r + 3, cx - r + 3, cy + r, color);      // стенки
        ctx.fill(cx + r - 1, cy - r + 3, cx + r + 1, cy + r, color);
        ctx.fill(cx - r + 1, cy + r - 1, cx + r + 1, cy + r + 1, color);  // дно
    }

    /** Стрелка «вернуть» (из удалённых). */
    private static void iconRestore(DrawContext ctx, int cx, int cy, int r, int color) {
        Draw.line(ctx, cx - r, cy, cx + r, cy, color);
        Draw.line(ctx, cx - r, cy, cx - r + r / 2, cy - r / 2, color);
        Draw.line(ctx, cx - r, cy, cx - r + r / 2, cy + r / 2, color);
    }

    // ------------------------------------------------------------------ строка модуля
    private void drawRow(DrawContext ctx, TextRenderer tr, Module m, int x, int y, int w, int h,
                         float a, int acc, float dt) {
        float tg = m.toggleAnim.v;
        int bg = Draw.mix(Theme.CARD, acc, 0.14f * tg);
        bg = Draw.mix(bg, 0xFFFFFF, 0.03f * m.hoverAnim.v);
        Draw.rrect(ctx, x, y, w, ROW, 6, Draw.argb(bg, 0.95f * a));
        Draw.outline(ctx, x, y, w, ROW, 6, Draw.argb(Draw.mix(Theme.BORDER, acc, 0.5f * tg), (0.7f + 0.3f * tg) * a));
        if (tg > 0.02f) Draw.rrect(ctx, x, y, 3, Math.round(ROW * tg), 2, Draw.argb(acc, a));

        int tx = x + 10;
        if (!m.settings.isEmpty()) {
            tx = x + 19;
            int cx = x + 10, cy = y + ROW / 2;
            int cc = Draw.argb(Draw.mix(Theme.TEXT_DIM, acc, m.expandAnim.v), a);
            if (m.expandAnim.v < 0.5f) {
                Draw.line(ctx, cx, cy - 3, cx + 3, cy, cc);
                Draw.line(ctx, cx + 3, cy, cx, cy + 3, cc);
            } else {
                Draw.line(ctx, cx - 1, cy - 2, cx + 2, cy + 1, cc);
                Draw.line(ctx, cx + 2, cy + 1, cx + 5, cy - 2, cc);
            }
        }

        int maxText = w - (tx - x) - 42;
        Draw.text(ctx, tr, Draw.trim(tr, m.name, maxText), tx, y + 6, Draw.mix(Theme.TEXT_DIM, 0xFFFFFF, tg), a);
        if (!m.description.isEmpty())
            Draw.text(ctx, tr, Draw.trim(tr, m.description, maxText), tx, y + 16, Theme.DESC, a * 0.92f);

        pill(ctx, x + w - 34, y + (ROW - 13) / 2, 24, 13, tg, acc, a);

        if (m.expandAnim.v > 0.02f) drawSettings(ctx, tr, m, x, y, w, a, acc, dt);
    }

    private static void pill(DrawContext ctx, int x, int y, int w, int h, float on, int acc, float a) {
        Draw.rrect(ctx, x, y, w, h, h / 2, Draw.argb(Draw.mix(Theme.TOGGLE_OFF, acc, on), (0.9f + 0.1f * on) * a));
        Draw.outline(ctx, x, y, w, h, h / 2, Draw.argb(Draw.mix(Theme.BORDER, acc, on), a));
        int k = h - 4;
        int kx = x + 2 + Math.round(on * (w - k - 4));
        Draw.rrect(ctx, kx, y + 2, k, k, k / 2, Draw.argb(Draw.mix(0xB9C4D4, 0xFFFFFF, on), a));
    }

    private static void checkbox(DrawContext ctx, int x, int y, int s, float on, int acc, float a) {
        Draw.rrect(ctx, x, y, s, s, 3, Draw.argb(Draw.mix(0x16203A, acc, on), 0.95f * a));
        Draw.outline(ctx, x, y, s, s, 3, Draw.argb(Draw.mix(Theme.BORDER, acc, on), (0.8f + 0.2f * on) * a));
        if (on > 0.05f) {
            int col = Draw.argb(0xFFFFFF, on * a);
            Draw.line(ctx, x + 3, y + s / 2, x + s / 2 - 1, y + s - 4, col);
            Draw.line(ctx, x + s / 2 - 1, y + s - 4, x + s - 3, y + 4, col);
        }
    }

    // ------------------------------------------------------------------ настройки
    private static int modeRows(TextRenderer tr, ModeSetting mo, int innerW) {
        int rows = 1, cx = 0;
        for (String m : mo.modes) {
            int w = Draw.w(tr, m) + 12;
            if (cx + w > innerW && cx > 0) { rows++; cx = 0; }
            cx += w + 4;
        }
        return rows;
    }

    private static int settingH(TextRenderer tr, Setting s, int w) {
        if (s instanceof NumberSetting) return 30;
        if (s instanceof ModeSetting mo) return 15 + modeRows(tr, mo, w - 20) * 18 + 3;
        return 22;
    }

    private static int settingsHeight(TextRenderer tr, Module m, int w) {
        if (m.settings.isEmpty()) return 0;
        int h = 8;
        for (Setting s : m.settings) h += settingH(tr, s, w);
        return h;
    }

    private void drawSettings(DrawContext ctx, TextRenderer tr, Module m, int x, int y, int w,
                              float a, int acc, float dt) {
        ctx.enableScissor(x, Math.max(y + ROW, listY), x + w, Math.min(y + m.uiH, listY + listH));
        float ea = a * m.expandAnim.v;
        ctx.fill(x + 8, y + ROW, x + w - 8, y + ROW + 1, Draw.argb(Theme.BORDER, 0.85f * ea));
        int ry = y + ROW + 5;
        for (Setting s : m.settings) {
            int sh = settingH(tr, s, w);
            s.ux = x; s.uy = ry; s.uw = w; s.uh = sh;
            if (s instanceof BoolSetting b) {
                b.anim.to(b.get() ? 1f : 0f, 16f, dt);
                Draw.text(ctx, tr, Draw.trim(tr, b.name, w - 46), x + 10, ry + 6, Theme.TEXT, ea);
                checkbox(ctx, x + w - 24, ry + 4, 12, b.anim.v, acc, ea);
            } else if (s instanceof NumberSetting n) {
                n.ux = x + 10; n.uw = w - 20;
                n.anim.to(n.frac(), 22f, dt);
                String vs = n.step >= 1 ? String.valueOf((int) Math.round(n.get()))
                        : String.format(Locale.ROOT, "%.2f", n.get());
                Draw.text(ctx, tr, n.name, x + 10, ry + 2, Theme.TEXT, ea);
                Draw.text(ctx, tr, vs, x + w - 10 - Draw.w(tr, vs), ry + 2, acc, ea);
                int fw = Math.round(n.anim.v * n.uw);
                Draw.rrect(ctx, n.ux, ry + 19, n.uw, 4, 2, Draw.argb(0x000000, 0.35f * ea));
                Draw.rrect(ctx, n.ux, ry + 19, Math.max(1, fw), 4, 2, Draw.argb(acc, ea));
                Draw.rrect(ctx, n.ux + fw - 5, ry + 16, 10, 10, 5, Draw.argb(acc, ea));
                Draw.rrect(ctx, n.ux + fw - 3, ry + 18, 6, 6, 3, Draw.argb(0xFFFFFF, ea));
            } else if (s instanceof ModeSetting mo) {
                Draw.text(ctx, tr, mo.name, x + 10, ry + 2, Theme.TEXT, ea);
                int cxp = x + 10, cyp = ry + 15;
                for (int i = 0; i < mo.modes.length; i++) {
                    int tw = Draw.w(tr, mo.modes[i]) + 12;
                    if (cxp + tw > x + w - 10 && cxp > x + 10) { cxp = x + 10; cyp += 18; }
                    boolean sel = i == mo.index();
                    Draw.rrect(ctx, cxp, cyp, tw, 15, 4, Draw.argb(sel ? acc : 0x16203A, (sel ? 0.9f : 0.85f) * ea));
                    Draw.outline(ctx, cxp, cyp, tw, 15, 4, Draw.argb(sel ? acc : Theme.BORDER, ea));
                    Draw.text(ctx, tr, mo.modes[i], cxp + 6, cyp + 4, sel ? 0x0B0E12 : Theme.TEXT_DIM, ea);
                    Chip ch = new Chip();
                    ch.mo = mo; ch.idx = i; ch.x = cxp; ch.y = cyp; ch.w = tw; ch.h = 15;
                    chips.add(ch);
                    cxp += tw + 4;
                }
            }
            ry += sh;
        }
        ctx.disableScissor();
    }

    // ------------------------------------------------------------------ поиск
    private void layoutResults(TextRenderer tr) {
        box.clear();
        results.clear();
        String q = query.toString().toLowerCase(Locale.ROOT);
        for (Module m : ModuleManager.modules)
            if (m.name.toLowerCase(Locale.ROOT).contains(q)) results.add(m);

        int y = listY;
        for (Module m : results) {
            m.uiX = listX;
            m.uiY = y;
            m.uiW = listW;
            m.uiH = ROW + Math.round(m.expandAnim.v * (settingsHeight(tr, m, listW - 2 * PAD) + 4));
            y += m.uiH + 4;
            visible.add(m);
        }
        contentH = y - listY;
        maxScroll = Math.max(0f, contentH - listH);
        scrollTarget = Math.max(0f, Math.min(maxScroll, scrollTarget));
        scroll.to(scrollTarget, 22f, frameDt);
    }

    private void drawResults(DrawContext ctx, TextRenderer tr, int mouseX, int mouseY,
                             float a, int acc, float dt) {
        ctx.enableScissor(0, listY, width, listY + listH);
        if (results.isEmpty()) {
            String s = "Ничего не найдено";
            Draw.text(ctx, tr, s, listX + (listW - Draw.w(tr, s)) / 2, listY + listH / 2 - 4, Theme.TEXT_DIM, a);
        }
        for (Module m : results) {
            int y = Math.round(m.uiY - scroll.v);
            m.uiY = y;
            m.toggleAnim.to(m.isEnabled() ? 1f : 0f, 14f, dt);
            m.expandAnim.to(m.expanded && !m.settings.isEmpty() ? 1f : 0f, 14f, dt);
            boolean hov = mouseX >= m.uiX && mouseX < m.uiX + m.uiW && mouseY >= y && mouseY < y + ROW
                    && mouseY >= listY && mouseY < listY + listH;
            m.hoverAnim.to(hov ? 1f : 0f, 16f, dt);
            if (y + m.uiH >= listY && y <= listY + listH)
                drawRow(ctx, tr, m, m.uiX, y, m.uiW, m.uiH, a, acc, dt);
        }
        ctx.disableScissor();
        scrollbar(ctx, a, acc);
    }

    // ------------------------------------------------------------------ ввод
    private static boolean in(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private void setSlider(NumberSetting s, double mx) {
        double f = Math.max(0.0, Math.min(1.0, (mx - s.ux) / (double) s.uw));
        double raw = s.min + f * (s.max - s.min);
        s.set(Math.round(raw / s.step) * s.step);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (open.v < 0.9f || closing) return true;

        // шапка: поиск
        if (my >= 2 && my < TOP) {
            if (in(mx, my, searchX, searchY, searchW, searchH)) { searching = true; return true; }
            if (searching) stopSearch();
            return true;
        }
        // фильтры
        for (int i = 0; i < 3; i++) {
            if (in(mx, my, 10 + i * (tabW() + GAP), tabY, tabW(), tabH)) {
                filter = i;
                selected = null;
                scrollTarget = 0f;
                return true;
            }
        }
        if (my < listY || my > listY + listH) return true;

        // слайдеры раскрытых модулей
        for (Module m : visible) {
            if (m.expandAnim.v < 0.6f) continue;
            for (Setting s : m.settings) {
                if (s instanceof NumberSetting n
                        && in(mx, my, n.ux - 6, n.uy + 14, n.uw + 12, 16)
                        && in(mx, my, m.uiX, m.uiY, m.uiW, m.uiH)) {
                    dragSlider = n;
                    setSlider(n, mx);
                    return true;
                }
            }
        }

        // папки
        if (!(searching && query.length() > 0)) {
            for (Category c : ORDER) {
                if (!matches(c)) continue;
                float[] r = box.get(c);
                if (r == null) continue;
                int x = Math.round(r[0]), y = Math.round(r[1]), w = Math.round(r[2]);
                if (!in(mx, my, x, y, w, HEAD)) continue;

                if (button == 1) { toggleOpen(c); return true; }   // правая кнопка — открыть/закрыть

                if (selected == c) {
                    int cy = y + HEAD / 2;
                    if (in(mx, my, x + w - 30, cy - 8, 16, 16)) {      // ★ избранное
                        if (FAV.contains(c)) FAV.remove(c); else FAV.add(c);
                        return true;
                    }
                    if (in(mx, my, x + w - 46, cy - 8, 16, 16)) {     // 🗑 удалить / вернуть
                        if (DEL.contains(c)) DEL.remove(c); else DEL.add(c);
                        return true;
                    }
                }
                pressWasSelected = selected == c;
                selected = c;
                pressArea = 2;
                dragCat = c;
                dragGrabY = (float) (my - y);
                dragCurY = (float) my;
                pressX = mx; pressY = my; moved = 0;
                return true;
            }
        }

        pressArea = 1;
        pressX = mx; pressY = my; moved = 0;
        return true;
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragSlider != null) { setSlider(dragSlider, mx); return true; }
        if (pressArea == 2 && dragCat != null) {
            moved += (float) (Math.abs(dx) + Math.abs(dy));
            dragCurY = (float) my;
            if (moved > 5f) reorder(my);
            return true;
        }
        if (pressArea == 1) {
            moved += (float) (Math.abs(dx) + Math.abs(dy));
            scrollTarget = Math.max(0f, Math.min(maxScroll, scrollTarget - (float) dy));
        }
        return true;
    }

    /** Перетаскивание папки: вставляем её туда, где сейчас курсор. */
    private void reorder(double my) {
        int idx = ORDER.indexOf(dragCat);
        if (idx < 0) return;
        int target = 0;
        for (Category c : ORDER) {
            if (c == dragCat) continue;
            float[] r = box.get(c);
            if (r == null) continue;
            if (my > r[1] + r[3] / 2f) target++;
        }
        target = Math.max(0, Math.min(ORDER.size() - 1, target));
        if (target == idx) return;
        ORDER.remove(idx);
        ORDER.add(target, dragCat);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (dragSlider != null) { dragSlider = null; return true; }
        int area = pressArea;
        pressArea = 0;
        if (area == 2 && dragCat != null) {
            if (moved < 6f && pressWasSelected) toggleOpen(dragCat);   // второй клик — открыть/закрыть
            dragCat = null;
            return true;
        }
        if (area == 1 && moved < 6) tap(pressX, pressY);
        return true;
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double h, double v) {
        scrollTarget = Math.max(0f, Math.min(maxScroll, scrollTarget - (float) v * 22f));
        return true;
    }

    private void tap(double mx, double my) {
        for (Module m : visible) {
            if (!in(mx, my, m.uiX, m.uiY, m.uiW, m.uiH)) continue;
            if (my < m.uiY + ROW) {
                if (!m.settings.isEmpty() && mx >= m.uiX + 5 && mx < m.uiX + 17) {
                    m.expanded = !m.expanded;
                    return;
                }
                m.toggle();
                return;
            }
            if (m.expandAnim.v > 0.6f) {
                for (Chip c : chips)
                    if (in(mx, my, c.x, c.y, c.w, c.h)) { c.mo.set(c.idx); return; }
                for (Setting s : m.settings)
                    if (s instanceof BoolSetting b && in(mx, my, b.ux, b.uy, b.uw, b.uh)) { b.toggle(); return; }
            }
            return;
        }
    }

    /** Устойчивое псевдослучайное число 0..1 (звёзды фона). */
    private static float rnd(int i, int salt) {
        int x = i * 374761393 + salt * 668265263;
        x = (x ^ (x >> 13)) * 1274126177;
        x ^= (x >> 16);
        return (x & 0x7FFFFFFF) / (float) 0x7FFFFFFF;
    }
}
