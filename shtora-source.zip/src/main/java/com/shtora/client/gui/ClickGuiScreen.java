package com.shtora.client.gui;

import com.shtora.client.Category;
import com.shtora.client.Module;
import com.shtora.client.ModuleManager;
import com.shtora.client.setting.BoolSetting;
import com.shtora.client.setting.ModeSetting;
import com.shtora.client.setting.NumberSetting;
import com.shtora.client.setting.Setting;
import com.shtora.client.util.Anim;
import com.shtora.client.util.Draw;
import com.shtora.client.util.Logo;
import com.shtora.client.util.Theme;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Меню клиента в стиле CS2: слева вертикальный рельс категорий, справа список модулей.
 * Квадратные углы, тонкие 1px рамки, оранжевый акцент. Логика (поиск, скролл, слайдеры, режимы)
 * сохранена полностью.
 */
public class ClickGuiScreen extends Screen {
    private static Category selected = Category.COMBAT;
    private static final int HH = 24, GAP = 5, RAIL_W = 104, HEADER_H = 26, RAIL_ITEM = 24;

    private static class Chip { ModeSetting mo; int idx, x, y, w, h; }

    private final Anim open = new Anim(0), switchCat = new Anim(1), scroll = new Anim(0), searchAnim = new Anim(0);
    private final Anim[] catSel = new Anim[Category.values().length];
    private final int[] railY = new int[Category.values().length];
    private final List<Chip> chips = new ArrayList<>();
    private final StringBuilder query = new StringBuilder();
    private List<Module> visible = new ArrayList<>();

    private boolean closing, searching, init;
    private float scrollTarget, maxScroll;
    private long last = System.nanoTime();
    private int wx, wy, ww, wh;
    private int railX, railTop, railH, railItemH = RAIL_ITEM;
    private int gx, gy, gw, gh;
    private int searchX, searchY, searchW, searchH;
    private int pressArea;
    private double pressX, pressY, moved;
    private NumberSetting dragSlider;

    public ClickGuiScreen() {
        super(Text.empty());
        for (int i = 0; i < catSel.length; i++) catSel[i] = new Anim(Category.values()[i] == selected ? 1f : 0f);
    }

    @Override public boolean shouldPause() { return false; }
    @Override public void close() { closing = true; }
    @Override public void renderBackground(DrawContext ctx, int mx, int my, float delta) {}

    // ------------------------------------------------------------ клавиатура
    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (searching) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE) { stopSearch(); return true; }
            if (keyCode == GLFW.GLFW_KEY_BACKSPACE) {
                if (query.length() > 0) query.setLength(query.length() - 1);
                return true;
            }
        }
        if (keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT && !searching) { close(); return true; }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (searching && chr >= 32 && query.length() < 24) {
            query.append(chr);
            scrollTarget = 0f;
            return true;
        }
        return super.charTyped(chr, modifiers);
    }

    private void stopSearch() { searching = false; query.setLength(0); }

    // ------------------------------------------------------------ раскладка настроек
    private static int modeRows(TextRenderer tr, ModeSetting mo, int innerW) {
        int rows = 1, cx = 0;
        for (String m : mo.modes) {
            int w = Draw.w(tr, m) + 12;
            if (cx + w > innerW && cx > 0) { rows++; cx = 0; }
            cx += w + 4;
        }
        return rows;
    }

    private static int settingH(TextRenderer tr, Setting s, int w) {
        if (s instanceof NumberSetting) return 30;
        if (s instanceof ModeSetting mo) return 15 + modeRows(tr, mo, w - 20) * 18 + 3;
        return 22;
    }

    private static int settingsHeight(TextRenderer tr, Module m, int w) {
        if (m.settings.isEmpty()) return 0;
        int h = 8;
        for (Setting s : m.settings) h += settingH(tr, s, w);
        return h;
    }

    // ------------------------------------------------------------ рендер
    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - last) / 1e9f);
        last = now;

        open.to(closing ? 0f : 1f, 12f, dt);
        if (closing && open.v < 0.03f) { client.setScreen(null); return; }
        float a = Draw.ease(open.v);

        TextRenderer tr = client.textRenderer;
        int acc = Theme.accent();
        var ui = ModuleManager.ui;

        if (ui.blur.get()) applyBlur();
        ctx.fill(0, 0, width, height, Draw.argb(0x000000, 0.35f * a));

        ww = Math.min(520, width - 10);
        wh = Math.min(300, height - 10);
        wx = (width - ww) / 2;
        wy = (height - wh) / 2 + Math.round((1f - a) * 14f);

        // окно: тёмная панель, квадратные углы, тонкая рамка
        float g = (float) ui.glass.get();
        ctx.fill(wx, wy, wx + ww, wy + wh, Draw.argb(Theme.PANEL, Math.max(0.3f, g) * a));
        Draw.box(ctx, wx, wy, wx + ww, wy + wh, Draw.argb(Theme.BORDER, 0.9f * a));
        // верхняя оранжевая полоса
        ctx.fill(wx, wy, wx + ww, wy + 2, Draw.argb(acc, a));
        // полоса заголовка
        ctx.fill(wx + 1, wy + 2, wx + ww - 1, wy + HEADER_H, Draw.argb(Theme.PANEL_ALT, 0.95f * a));
        ctx.fill(wx + 1, wy + HEADER_H, wx + ww - 1, wy + HEADER_H + 1, Draw.argb(Theme.BORDER, 0.9f * a));

        drawHeader(ctx, tr, a, acc, dt);

        // рельс категорий
        railX = wx + 1;
        railTop = wy + HEADER_H + 1;
        railH = wh - HEADER_H - 2;
        ctx.fill(railX, railTop, railX + RAIL_W, railTop + railH, Draw.argb(Theme.PANEL_ALT, 0.55f * a));
        ctx.fill(railX + RAIL_W, railTop, railX + RAIL_W + 1, railTop + railH, Draw.argb(Theme.BORDER, 0.85f * a));
        drawRail(ctx, tr, mouseX, mouseY, a, acc, dt);

        gx = railX + RAIL_W + 1 + 8;
        gy = railTop + 8;
        gw = wx + ww - 8 - gx;
        gh = railTop + railH - 8 - gy;
        switchCat.to(1f, 12f, dt);
        drawGrid(ctx, tr, mouseX, mouseY, a * switchCat.v, acc, dt);
    }

    private void drawHeader(DrawContext ctx, TextRenderer tr, float a, int acc, float dt) {
        int top = wy + 2;
        // логотип
        ctx.fill(wx + 8, top + 5, wx + 22, top + 19, Draw.argb(acc, a));
        Logo.body(ctx, wx + 11, top + 7, 7, 10, 0x0B0E12, a);
        Draw.text(ctx, tr, "SHTORA", wx + 27, top + 8, acc, a);
        Draw.text(ctx, tr, " CLIENT", wx + 27 + Draw.w(tr, "SHTORA"), top + 8, Theme.TEXT, a);

        // поле поиска
        searchAnim.to(searching ? 1f : 0f, 14f, dt);
        searchW = Math.min(150, Math.max(70, ww / 3));
        searchH = 16;
        searchX = wx + ww - 8 - searchW;
        searchY = top + 4;
        ctx.fill(searchX, searchY, searchX + searchW, searchY + searchH,
                Draw.argb(Draw.mix(0x0B0E12, acc, 0.18f * searchAnim.v), 0.95f * a));
        Draw.box(ctx, searchX, searchY, searchX + searchW, searchY + searchH,
                Draw.argb(Draw.mix(Theme.BORDER, acc, searchAnim.v), (0.8f + 0.2f * searchAnim.v) * a));

        int ic = Draw.mix(Theme.TEXT_DIM, acc, searchAnim.v);
        Draw.outline(ctx, searchX + 6, searchY + 4, 7, 7, 3, Draw.argb(ic, a));
        ctx.fill(searchX + 12, searchY + 10, searchX + 14, searchY + 12, Draw.argb(ic, a));

        String shown = searching ? Draw.trim(tr, query.toString(), searchW - 28) : "SEARCH";
        Draw.text(ctx, tr, shown, searchX + 18, searchY + 4, searching ? Theme.TEXT : Theme.TEXT_DIM, a);
        if (searching && (System.currentTimeMillis() / 500) % 2 == 0) {
            int cx = searchX + 18 + Draw.w(tr, shown);
            ctx.fill(cx + 1, searchY + 3, cx + 2, searchY + 13, Draw.argb(acc, a));
        }
    }

    private void drawRail(DrawContext ctx, TextRenderer tr, int mx, int my, float a, int acc, float dt) {
        Category[] cats = Category.values();
        railItemH = Math.min(RAIL_ITEM, Math.max(16, (railH - 44) / cats.length));
        int y = railTop + 8;
        for (int i = 0; i < cats.length; i++) {
            railY[i] = y;
            boolean sel = cats[i] == selected;
            boolean hov = mx >= railX && mx < railX + RAIL_W && my >= y && my < y + railItemH;
            catSel[i].to(sel ? 1f : 0f, 14f, dt);
            float s = catSel[i].v;
            if (s > 0.02f) ctx.fill(railX + 1, y, railX + RAIL_W, y + railItemH, Draw.argb(acc, 0.13f * s * a));
            if (hov && !sel) ctx.fill(railX + 1, y, railX + RAIL_W, y + railItemH, Draw.argb(0xFFFFFF, 0.04f * a));
            int barH = Math.round(railItemH * s);
            if (barH > 0) ctx.fill(railX + 1, y + (railItemH - barH) / 2, railX + 4, y + (railItemH - barH) / 2 + barH, Draw.argb(acc, a));
            Draw.text(ctx, tr, cats[i].title, railX + 12, y + (railItemH - 8) / 2, Draw.mix(Theme.TEXT_DIM, 0xFFFFFF, s), a);
            y += railItemH + 2;
        }
        if (y + 6 < railTop + railH) {
            String tag = "R-SHIFT — ЗАКРЫТЬ";
            Draw.text(ctx, tr, tag, railX + 10, railTop + railH - 14, Theme.TEXT_DIM, a * 0.55f);
        }
    }

    private void refreshVisible() {
        if (searching && query.length() > 0) {
            String q = query.toString().toLowerCase(Locale.ROOT);
            List<Module> out = new ArrayList<>();
            for (Module m : ModuleManager.modules) if (m.name.toLowerCase(Locale.ROOT).contains(q)) out.add(m);
            visible = out;
        } else {
            visible = ModuleManager.byCategory(selected);
        }
    }

    private void drawGrid(DrawContext ctx, TextRenderer tr, int mouseX, int mouseY, float ca, int acc, float dt) {
        refreshVisible();
        chips.clear();

        int cols = gw >= 420 ? 3 : gw >= 250 ? 2 : 1;
        int colW = (gw - GAP * (cols - 1)) / cols;
        float[] colY = new float[cols];

        for (int i = 0; i < visible.size(); i++) {
            Module m = visible.get(i);
            m.toggleAnim.to(m.isEnabled() ? 1f : 0f, 14f, dt);
            m.expandAnim.to(m.expanded && !m.settings.isEmpty() ? 1f : 0f, 14f, dt);
            int c = i % cols;
            int h = HH;
            if (!m.settings.isEmpty()) h += Math.round(m.expandAnim.v * (settingsHeight(tr, m, colW) + 4));
            m.uiX = gx + c * (colW + GAP);
            m.uiW = colW;
            m.uiH = h;
            m.uiY = Math.round(colY[c]);
            colY[c] += h + GAP;
        }
        float contentH = 0;
        for (float v : colY) contentH = Math.max(contentH, v - GAP);
        maxScroll = Math.max(0f, contentH - gh);
        scrollTarget = Math.max(0f, Math.min(maxScroll, scrollTarget));
        scroll.to(scrollTarget, 22f, dt);
        float slide = (1f - Draw.ease(switchCat.v)) * 8f;

        if (visible.isEmpty()) {
            String s = searching ? "Nothing found" : "Coming soon";
            Draw.text(ctx, tr, s, gx + (gw - Draw.w(tr, s)) / 2, gy + gh / 2 - 4, Theme.TEXT_DIM, ca);
        }

        ctx.enableScissor(gx - 2, gy, gx + gw + 2, gy + gh);
        for (Module m : visible) {
            m.uiY = Math.round(gy + m.uiY - scroll.v + slide);
            boolean hov = mouseX >= m.uiX && mouseX < m.uiX + m.uiW && mouseY >= m.uiY && mouseY < m.uiY + HH
                    && mouseY >= gy && mouseY < gy + gh;
            m.hoverAnim.to(hov ? 1f : 0f, 16f, dt);
            if (m.uiY + m.uiH >= gy && m.uiY <= gy + gh) drawCard(ctx, tr, m, ca, acc, dt);
        }
        ctx.disableScissor();

        if (maxScroll > 0f) {
            int sbh = Math.max(14, Math.round(gh * gh / contentH));
            int sby = gy + Math.round((gh - sbh) * (scroll.v / maxScroll));
            ctx.fill(gx + gw + 3, sby, gx + gw + 5, sby + sbh, Draw.argb(acc, 0.7f * ca));
        }
    }

    /** Квадратный чекбокс с галочкой. */
    private static void checkbox(DrawContext ctx, int x, int y, int s, float on, int acc, float a) {
        ctx.fill(x, y, x + s, y + s, Draw.argb(Draw.mix(0x1A1E25, acc, on), 0.95f * a));
        Draw.box(ctx, x, y, x + s, y + s, Draw.argb(Draw.mix(Theme.BORDER, acc, on), (0.8f + 0.2f * on) * a));
        if (on > 0.05f) {
            int col = Draw.argb(0xFFFFFF, on * a);
            Draw.line(ctx, x + 3, y + s / 2, x + s / 2 - 1, y + s - 4, col);
            Draw.line(ctx, x + s / 2 - 1, y + s - 4, x + s - 3, y + 4, col);
        }
    }

    private void drawCard(DrawContext ctx, TextRenderer tr, Module m, float ca, int acc, float dt) {
        int x = m.uiX, y = m.uiY, w = m.uiW, h = m.uiH;
        float tg = m.toggleAnim.v, ex = m.expandAnim.v;

        int bg = Draw.mix(0x14171C, acc, 0.10f * tg);
        int bd = Draw.mix(Theme.BORDER, acc, 0.55f * tg);
        ctx.fill(x, y, x + w, y + h, Draw.argb(Draw.mix(bg, 0xFFFFFF, 0.03f * m.hoverAnim.v), 0.94f * ca));
        Draw.box(ctx, x, y, x + w, y + h, Draw.argb(bd, (0.75f + 0.25f * tg) * ca));

        int barH = Math.round(HH * tg);
        if (barH > 0) ctx.fill(x, y, x + 3, y + barH, Draw.argb(acc, ca));

        Draw.text(ctx, tr, Draw.trim(tr, m.name, w - 60), x + 10, y + 8, Draw.mix(Theme.TEXT_DIM, 0xFFFFFF, tg), ca);

        // кнопка раскрытия настроек
        if (!m.settings.isEmpty()) {
            int bx = x + w - 44, by = y + 5;
            ctx.fill(bx, by, bx + 14, by + 14, Draw.argb(Draw.mix(0x1A1E25, acc, ex), 0.95f * ca));
            Draw.box(ctx, bx, by, bx + 14, by + 14, Draw.argb(Draw.mix(Theme.BORDER, acc, ex), 0.9f * ca));
            int pc = Draw.argb(0xFFFFFF, ca);
            ctx.fill(bx + 3, by + 6, bx + 11, by + 8, pc);
            if (ex < 0.5f) ctx.fill(bx + 6, by + 3, bx + 8, by + 11, pc);
        }
        // чекбокс включения модуля
        checkbox(ctx, x + w - 26, y + 5, 14, tg, acc, ca);

        if (ex > 0.02f) {
            ctx.enableScissor(x, Math.max(y, gy), x + w, Math.min(y + h, gy + gh));
            float ea = ca * ex;
            ctx.fill(x + 8, y + HH, x + w - 8, y + HH + 1, Draw.argb(Theme.BORDER, 0.85f * ea));
            int ry = y + HH + 5;
            for (Setting s : m.settings) {
                int sh = settingH(tr, s, w);
                s.ux = x; s.uy = ry; s.uw = w; s.uh = sh;
                if (s instanceof BoolSetting b) {
                    b.anim.to(b.get() ? 1f : 0f, 16f, dt);
                    Draw.text(ctx, tr, Draw.trim(tr, b.name, w - 46), x + 10, ry + 6, Theme.TEXT, ea);
                    checkbox(ctx, x + w - 24, ry + 4, 12, b.anim.v, acc, ea);
                } else if (s instanceof NumberSetting n) {
                    n.ux = x + 10; n.uw = w - 20;
                    n.anim.to(n.frac(), 22f, dt);
                    String vs = n.step >= 1 ? String.valueOf((int) Math.round(n.get()))
                            : String.format(Locale.ROOT, "%.2f", n.get());
                    Draw.text(ctx, tr, n.name, x + 10, ry + 2, Theme.TEXT, ea);
                    Draw.text(ctx, tr, vs, x + w - 10 - Draw.w(tr, vs), ry + 2, acc, ea);
                    int fw = Math.round(n.anim.v * n.uw);
                    ctx.fill(n.ux, ry + 19, n.ux + n.uw, ry + 23, Draw.argb(0x000000, 0.35f * ea));
                    ctx.fill(n.ux, ry + 19, n.ux + fw, ry + 23, Draw.argb(acc, ea));
                    ctx.fill(n.ux + fw - 4, ry + 16, n.ux + fw + 4, ry + 26, Draw.argb(acc, ea));
                    ctx.fill(n.ux + fw - 3, ry + 17, n.ux + fw + 3, ry + 25, Draw.argb(0xFFFFFF, ea));
                } else if (s instanceof ModeSetting mo) {
                    Draw.text(ctx, tr, mo.name, x + 10, ry + 2, Theme.TEXT, ea);
                    int cxp = x + 10, cyp = ry + 15;
                    for (int i = 0; i < mo.modes.length; i++) {
                        int tw = Draw.w(tr, mo.modes[i]) + 12;
                        if (cxp + tw > x + w - 10 && cxp > x + 10) { cxp = x + 10; cyp += 18; }
                        boolean sel = i == mo.index();
                        ctx.fill(cxp, cyp, cxp + tw, cyp + 15, Draw.argb(sel ? acc : 0x1A1E25, (sel ? 0.9f : 0.85f) * ea));
                        Draw.box(ctx, cxp, cyp, cxp + tw, cyp + 15, Draw.argb(sel ? acc : Theme.BORDER, ea));
                        Draw.text(ctx, tr, mo.modes[i], cxp + 6, cyp + 4, sel ? 0x0B0E12 : Theme.TEXT_DIM, ea);
                        Chip c = new Chip();
                        c.mo = mo; c.idx = i; c.x = cxp; c.y = cyp; c.w = tw; c.h = 15;
                        chips.add(c);
                        cxp += tw + 4;
                    }
                }
                ry += sh;
            }
            ctx.disableScissor();
        }
    }

    // ------------------------------------------------------------ ввод
    private static boolean in(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private void select(Category c) {
        stopSearch();
        if (c == selected) return;
        selected = c;
        switchCat.v = 0f;
        scrollTarget = 0f;
        scroll.v = 0f;
    }

    private void setSlider(NumberSetting s, double mx) {
        double f = Math.max(0.0, Math.min(1.0, (mx - s.ux) / (double) s.uw));
        double raw = s.min + f * (s.max - s.min);
        s.set(Math.round(raw / s.step) * s.step);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (open.v < 0.9f || closing) return true;
        if (!in(mx, my, wx, wy, ww, wh)) { close(); return true; }

        // шапка: поле поиска
        if (my >= wy + 2 && my < wy + HEADER_H) {
            if (in(mx, my, searchX, searchY, searchW, searchH)) { searching = true; return true; }
            if (searching) stopSearch();
            return true;
        }

        // рельс категорий
        if (in(mx, my, railX, railTop, RAIL_W, railH)) {
            Category[] cats = Category.values();
            for (int i = 0; i < cats.length; i++) {
                if (my >= railY[i] && my < railY[i] + railItemH) { select(cats[i]); return true; }
            }
            return true;
        }

        pressArea = 0;
        if (in(mx, my, gx, gy, gw, gh)) {
            for (Module m : visible) {
                if (m.expandAnim.v < 0.6f) continue;
                for (Setting s : m.settings) {
                    if (s instanceof NumberSetting n && in(mx, my, n.ux - 6, n.uy + 14, n.uw + 12, 16)
                            && in(mx, my, m.uiX, m.uiY, m.uiW, m.uiH)) {
                        dragSlider = n;
                        setSlider(n, mx);
                        return true;
                    }
                }
            }
            pressArea = 1;
            pressX = mx; pressY = my; moved = 0;
        }
        return true;
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragSlider != null) { setSlider(dragSlider, mx); return true; }
        if (pressArea == 1) {
            moved += Math.abs(dx) + Math.abs(dy);
            scrollTarget = Math.max(0f, Math.min(maxScroll, scrollTarget - (float) dy));
        }
        return true;
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (dragSlider != null) { dragSlider = null; return true; }
        int area = pressArea;
        pressArea = 0;
        if (area == 1 && moved < 6) tap(pressX, pressY);
        return true;
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double h, double v) {
        scrollTarget = Math.max(0f, Math.min(maxScroll, scrollTarget - (float) v * 22f));
        return true;
    }

    private void tap(double mx, double my) {
        for (Module m : visible) {
            if (!in(mx, my, m.uiX, m.uiY, m.uiW, m.uiH)) continue;
            if (my < m.uiY + HH) {
                boolean expandBtn = !m.settings.isEmpty()
                        && mx >= m.uiX + m.uiW - 44 && mx < m.uiX + m.uiW - 30;
                if (expandBtn) m.expanded = !m.expanded; else m.toggle();
                return;
            }
            if (m.expandAnim.v > 0.6f) {
                for (Chip c : chips) {
                    if (in(mx, my, c.x, c.y, c.w, c.h)) { c.mo.set(c.idx); return; }
                }
                for (Setting s : m.settings) {
                    if (s instanceof BoolSetting b && in(mx, my, b.ux, b.uy, b.uw, b.uh)) { b.toggle(); return; }
                }
            }
            return;
        }
    }
}
